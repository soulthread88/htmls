# EP28 — AI IMAGE GENERATION PROMPTS
# AI Diet Management — Snap a Photo, Get Instant Nutrition Analysis
# Updated: 2026-04-28

---

## IMAGE SLOT 1 — Intro / Blog Header (16:9)
Context: Senior photographing their meal with AI nutrition overlay

### Midjourney v6:
```
elderly american man (70s) photographing a colorful healthy meal on a dining table with his smartphone, AI nutritional data overlay visible on the phone screen showing calorie counts and nutrition bars, warm natural kitchen lighting, realistic photography style, educational technology feel, 16:9 --ar 16:9 --v 6 --style raw
```

### DALL-E 3:
```
Photorealistic image: A smiling elderly man (70s) pointing his smartphone at a colorful meal on a dining table. The phone screen shows an AI nutrition analysis overlay with calorie and nutrient data. Warm, natural kitchen lighting. Horizontal 16:9 composition. No real brand logos visible.
```

### Stock Alternative Search:
- "senior man photographing food smartphone"
- "elderly person healthy meal nutrition app"
- "food tracking app smartphone meal"

---

## IMAGE SLOT 2 — Tech Concept (16:9)
Context: Noom traffic light food classification visual

### Midjourney v6:
```
clean infographic showing three circles in green yellow red traffic light arrangement, each filled with healthy food illustrations, green circle with vegetables and fruits, yellow circle with lean proteins, red circle with processed foods, white background, modern flat design, educational health infographic, 16:9 --ar 16:9 --v 6
```

### DALL-E 3:
```
Clean educational infographic: Three circular sections arranged like a traffic light (vertical). Top circle = GREEN filled with vegetables, fruits, salad. Middle circle = YELLOW filled with chicken, eggs, beans. Bottom circle = RED filled with chips, cake, fried food. White background. Modern flat design. No text.
```

---

## IMAGE SLOT 3 — Saying / Hippocrates (16:9)
Context: "Let food be thy medicine" — ancient wisdom

### Midjourney v6:
```
vintage illustrated apothecary table with colorful fresh vegetables and fruits alongside ancient medical instruments, warm earthy tones, classical painting style, no text, food as medicine concept art, still life composition, 16:9 --ar 16:9 --v 6 --style expressive
```

### DALL-E 3:
```
Classical still-life painting style: An antique wooden table with colorful fresh vegetables and fruits (tomatoes, carrots, berries, leafy greens) arranged alongside a vintage mortar and pestle and old medicine bottles. Warm amber and earthy tones. No text. Horizontal 16:9.
```

---

## VISUAL STORY PANELS (1:1 Square)

### Panel 1 — "Grandpa's Plate Gets an AI Checkup!"
```
friendly cartoon illustration of a worried elderly man looking at his dinner plate with a puzzled expression, thought bubble showing question marks about nutrition, warm kitchen background, educational cartoon style, square format --ar 1:1 --v 6
```

### Panel 2 — "AI Calculates Every Calorie!"
```
cartoon illustration of a smartphone hovering over a dinner plate, colorful nutritional data beams scanning the food, calories and nutrient numbers floating up from the plate, cheerful tech magic effect, educational cartoon style, square format --ar 1:1 --v 6
```

### Panel 3 — "A Healthier Plate — AI Approved!"
```
cartoon illustration of a happy elderly man holding up a smartphone showing a green checkmark nutrition score, healthy colorful meal in front of him, thumbs up gesture, bright and warm colors, celebratory educational cartoon, square format --ar 1:1 --v 6
```

---

## AI ICON GRID (4 × 1:1 small squares)

### Icon 1 — Camera/Photo (📸)
```
minimalist icon: camera lens with food fork and spoon inside the lens circle, flat design, warm orange and white colors, clean app icon style, 1:1 square
```

### Icon 2 — Calendar/7-Day (📅)
```
minimalist icon: calendar grid with 7 days marked, green checkmarks on healthy days, clean modern calendar icon, teal and white colors, 1:1 square
```

### Icon 3 — Hospital/Health (🏥)
```
minimalist icon: medical cross inside heart shape, health and wellness aesthetic, red and white on light background, clean medical icon, 1:1 square
```

### Icon 4 — Water Drop (💧)
```
minimalist icon: blue water drop with sparkle effect, hydration reminder aesthetic, clean flat design, blue gradient, 1:1 square
```

---

## YOUTUBE THUMBNAIL SPEC

**Concept:** Before vs After transformation
- LEFT: Handwritten messy food diary (crumpled, overwhelming) — RED X stamp
- RIGHT: Clean phone screen showing "980 cal ✅ All nutrients tracked" — GREEN checkmark
- CENTER TEXT: "ONE PHOTO → FULL NUTRITION" (bold yellow, dark background)
- Bottom: "AI Decoded for Seniors | EP.28" gold on navy

**Canva template:** YouTube Thumbnail → "Before After" layout

---

## IMAGE SPECIFICATIONS

| Slot | Size | Format |
|---|---|---|
| Blog Headers (1,2,3) | 1200×630 | JPG |
| YouTube Thumbnail | 1280×720 | JPG |
| Story Panels (×3) | 1080×1080 | JPG/PNG |
| Icon Grid (×4) | 400×400 | PNG |
| Instagram Carousel | 1080×1080 | JPG |
| Instagram Story | 1080×1920 | JPG |

## ⚖️ COPYRIGHT NOTE
All generated images are original AI creations — no copyright issues.
Never include real app logos (Calorie Mama, Noom) in generated images.
For app screenshots: caption as "Screenshot: [App Name], [Date]"
