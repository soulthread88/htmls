# EP30 — SNS PLATFORM COPY PACK
# AI Shopping Comparison — The Secret to Finding the Lowest Price Every Time
# All platforms ready | Updated: 2026-04-28

---

## 📸 INSTAGRAM CAROUSEL — 10 Slides

**SLIDE 1 (Shock Hook):**
BIG TEXT: "He paid $70. His neighbor paid $52. Same product. Same week."
Sub: "Here's the free tool that shows the REAL Amazon price. 🐪"
CTA: "Swipe for the system →"

**SLIDE 2 (The Problem):**
"Why people overpay online every day:"
"🔴 Amazon changes prices THOUSANDS of times daily"
"🔴 'Was $89, Now $59' — often completely fabricated"
"🔴 Searching only Amazon = missing cheaper options elsewhere"
"🔴 Buying the wrong product = paying full price for the wrong item"
"→ 3 free AI tools fix ALL of this."

**SLIDE 3 (Step 1 — Google Shopping):**
"STEP 1 — Google Shopping (Free)"
"→ Search product name on Google"
"→ Click the 'Shopping' tab"
"→ Sort by 'Price: Low to High'"
"= Same product. Every major store. One view."
"Takes 90 seconds. Saves 10–15% every time."

**SLIDE 4 (Google Shopping Real Example):**
"Real example — Blood Pressure Monitor:"
"Amazon: $69.99"
"Walmart.com: $58.00"
"Medical supply store: $54.99 FREE shipping"
"⬆️ Found with Google Shopping in 90 seconds"
"💰 Saved $15 before clicking anything"

**SLIDE 5 (Step 2 — CamelCamelCamel):**
"STEP 2 — CamelCamelCamel.com (Free)"
"Is that Amazon 'sale' actually a deal?"
"→ Go to camelcamelcamel.com"
"→ Paste the Amazon product URL"
"→ See the REAL price history graph"
"If today's price > historical average → wait."

**SLIDE 6 (CamelCamelCamel Reveal):**
"Real example — 'Sale Price' exposed:"
"'Sale' price shown: $64.99"
"Historical average price: $58.00"
"Historical lowest price: $44.99"
"→ The 'sale' was ABOVE average. Not a deal."
"Waited 2 weeks → price dropped to $49.99 ✅"

**SLIDE 7 (Step 3 — ChatGPT):**
"STEP 3 — ChatGPT (Free)"
"The tool that finds the RIGHT product for YOU"
"Prompt: 'Best blood pressure monitor under $70"
"for a 72-year-old with arthritis. Large buttons."
"Big display. Simple operation.'"
"→ 3 specific recommendations. Pros + cons. Tailored to YOUR needs."

**SLIDE 8 (The Real Price Formula):**
"REAL LOWEST PRICE FORMULA:"
"Base Price"
"+ Shipping Cost"
"− Payment Discounts (cashback card, PayPal)"
"= TRUE price you pay"
"🚫 Never compare base prices alone."
"✅ Always calculate the total."

**SLIDE 9 (3 Rules — Every Purchase):**
"3 RULES — Before clicking Buy Now:"
"1️⃣ Check Google Shopping first (90 sec)"
"2️⃣ Verify Amazon price on CamelCamelCamel (2 min)"
"3️⃣ Ask ChatGPT for the right product for YOUR needs"
"In order. Every time. Never overpay again."

**SLIDE 10 (CTA):**
"🔗 Full guide + video in bio"
"Full episode: AI Decoded for Seniors EP.30"
"3 tools: Google Shopping · CamelCamelCamel · ChatGPT"
"All free. All take under 5 minutes total."
"Follow @AIDecodedForSeniors — daily senior AI tips 💰"

---

**Instagram Caption:**

He paid $70. His neighbor paid $52. Same blood pressure monitor. Same Amazon. Same week.

The difference? His neighbor knew about three free tools that take less than 5 minutes total — and guarantee the lowest real price every time. 💰

In Episode 30 of AI Decoded for Seniors, Jake breaks down the complete smart shopping system:

🔍 **Google Shopping** — see the same product across EVERY major US retailer at once, sorted by lowest total price. 90 seconds. Finds cheaper options Amazon never shows you.

🐪 **CamelCamelCamel** — reveals Amazon's complete price history. That "Was $89, Now $59 — 33% off!" label? Often fabricated. CamelCamelCamel shows you the truth in 10 seconds.

🤖 **ChatGPT** — describe your specific needs (age, health condition, hand mobility, budget) and get personalized product recommendations that actually fit your life. Then price-check those specific models.

These three tools, in order, before every purchase: 5 minutes that can save you $10–$20 every time you shop online.

Swipe through all 10 slides for the complete system — then drop your biggest online shopping frustration in the comments! 💬

*Sources: Google Shopping (shopping.google.com); CamelCamelCamel.com (2025); OpenAI ChatGPT (2025)*

#SmartShopping #PriceComparison #CamelCamelCamel #GoogleShopping #AmazonDeals #AIShoppingTips #SaveMoney #OnlineShopping #BestPrice #DealFinder #SeniorShopping #AIForSeniors #ShoppingHacks #PriceTracker #BudgetShopping #ShopSmart #ChatGPTShopping #AmazonTips #LowestPrice #ShoppingAI #SeniorTech #MoneyMindful #SmartBuying #PriceAlerts #ConsumerTips #AIDecoded #LearnAI #SeniorLife #ShoppingSmarter #ValueHunter

---

## 🎵 TIKTOK

**Caption:**
Amazon showed him a "33% off sale" on a blood pressure monitor. CamelCamelCamel showed the truth: the "sale" price was actually ABOVE the normal average. He waited 2 weeks. Saved $15 on the same product. camelcamelcamel.com — free. #CamelCamelCamel #AmazonDeals #SmartShopping #AIForSeniors #PriceTracker #SaveMoney #OnlineShopping #ShoppingHacks

**Hook (first 3 words):** "That Amazon sale—"

**Trending sound tip:** Use a "cash register" or "coin drop" sound effect when revealing the price difference — creates a satisfying audio cue tied to the money-saving moment. High retention because the hook creates immediate curiosity ("what's wrong with the sale?").

**TikTok duet/stitch angle:** Challenge: "Check your last Amazon purchase on CamelCamelCamel and stitch this video with what you found. Was YOUR price a real deal?" — generates UGC at zero cost and massive engagement from the outrage/surprise factor.

---

## 👥 FACEBOOK

**Facebook Post:**

💰 **Do you shop online? Please read this before your next purchase.**

Grandpa Bob paid $69.99 for a blood pressure monitor on Amazon. His neighbor bought the exact same model, same week, for $51.87.

Same product. Same Amazon listing. Different day, different price. Amazon changes prices thousands of times per day — and most shoppers have no idea.

Here's the complete free system Jake teaches in Episode 30 — and it takes less than 5 minutes before any purchase:

**🔍 Step 1: Google Shopping (90 seconds)**
Don't search Amazon first. Go to Google → type the exact product name → click the "Shopping" tab → sort by "Price: Low to High."

You'll see the same product across Amazon, Walmart, Target, and dozens of specialty retailers — all at once, all with shipping costs included. In 90 seconds. For free.

Result: Grandpa Bob found his monitor at a medical supply retailer for $54.99 with free shipping — $15 cheaper than Amazon, found in 90 seconds.

**🐪 Step 2: CamelCamelCamel (2 minutes)**
Before buying anything on Amazon, go to camelcamelcamel.com and paste the Amazon product link. It shows you the complete price history of that product going back years.

That "Was $89.99 — Now $59.99, Save 33%!" label? CamelCamelCamel will tell you if $59.99 is actually the normal everyday price with a fake "was" number attached. (This happens far more often than Amazon would like you to know.)

You can also set a Price Drop Alert — enter your email and target price, and CamelCamelCamel emails you automatically when the price drops. Never check manually again.

**🤖 Step 3: ChatGPT (3 minutes)**
For any purchase you're not 100% certain about, describe your specific needs to ChatGPT:
"Recommend the best blood pressure monitor under $70 for a 72-year-old with mild arthritis. I need large buttons, a big display, and simple one-touch operation."

ChatGPT returns specific model recommendations tailored to your age, health situation, and usage needs — not just the cheapest or most popular option.

Then take those model names and run them through Google Shopping and CamelCamelCamel.

**The Real Lowest Price Formula:**
Base price + Shipping − Payment discounts (cashback cards, PayPal, store credits) = True price.

Never compare base prices alone.

👉 Full video guide: [LINK]
👉 Korean version: [LINK]

Please share this with family members who shop online. This information is free — and it can save real money on every single purchase from this point forward. 💰

*Disclaimer: Prices and availability vary. Always verify current pricing before purchasing. CamelCamelCamel is an independent price tracking service, not affiliated with Amazon.*

*Sources: Google Shopping Official Documentation (2025); CamelCamelCamel.com (2025); Consumer Reports "Online Price Tracking Tools," 2025*

#SmartShopping #PriceComparison #CamelCamelCamel #GoogleShopping #AmazonDeals #SaveMoney #OnlineShopping #SeniorTech #AIForSeniors #BestPrice

---

## 🐦 X (TWITTER) THREAD

**Tweet 1 — Hook (Outrage + Curiosity):**
Grandpa Bob paid $69.99 for a blood pressure monitor on Amazon.

His neighbor bought the exact same model, same week: $51.87.

Same product. Same listing. Amazon changes prices thousands of times per day.

Here's the free tool that exposes the real price — in 10 seconds: [1/9]

**Tweet 2:**
CamelCamelCamel.com — free.

Paste any Amazon product URL.
See the complete price history. Years of data.
Today's price vs. historical average vs. historical low.

That "33% off sale" label?
CamelCamelCamel shows whether it's real — or fabricated.

Usually: fabricated. [2/9]

**Tweet 3:**
Real example I ran this week:

Amazon "sale" price: $64.99
Historical average: $58.00
Historical lowest: $44.99

The "sale" was $6.99 ABOVE average.
Waited 2 weeks.
Price dropped to $49.99.
Saved $15 by not clicking "Buy Now" on day one. [3/9]

**Tweet 4:**
Step 1 before ANY online purchase: Google Shopping.

Google → type exact product name → click "Shopping" tab → sort "Price: Low to High."

Same product. Every major US retailer. Shipping included. All at once.

Takes 90 seconds.
Saves 10–15% almost every time. [4/9]

**Tweet 5:**
Step 3: ChatGPT for the right product.

Most people buy the cheapest option.
Then return it because it's wrong for their situation.

ChatGPT prompt:
"Best blood pressure monitor under $70 for a 72-year-old with mild arthritis. Large buttons. Big display. One-touch."

Result: 3 specific models + pros/cons tailored to that exact situation. [5/9]

**Tweet 6:**
The Real Lowest Price Formula:

Base price + Shipping − Payment discounts = True price

$54.99 + $0 shipping − 3% cashback = $53.34 ✅
$52.99 + $8.99 shipping = $61.98 ❌

Never compare base prices alone.
Always do the full math. [6/9]

**Tweet 7:**
3 rules before clicking Buy Now:

1. Check Google Shopping (90 sec) — never buy from the first site you see
2. Check CamelCamelCamel for anything on Amazon (2 min) — verify the sale is real
3. Ask ChatGPT for personalized recommendations (3 min) — buy the RIGHT product

5 minutes. Never overpay again. [7/9]

**Tweet 8:**
"Look before you leap." — American proverb

Before you click Buy Now → look at Google Shopping.
Before you trust an Amazon sale → look at CamelCamelCamel.
Before you choose a product → look at ChatGPT's recommendation for YOUR needs.

Three looks. Every leap. [8/9]

**Tweet 9 — CTA:**
Full step-by-step guide (English + Korean):
👉 [YouTube link]
👉 [Blog link]

Check your last Amazon purchase on CamelCamelCamel.
Reply with what you find — was your price a real deal?

#SmartShopping #CamelCamelCamel #AmazonDeals #AIForSeniors #SaveMoney [9/9]

---

## 🧵 THREADS

**Post 1:**
Grandpa Bob paid $69.99 for a blood pressure monitor.

His neighbor paid $51.87. Same product. Same Amazon. Same week.

Amazon changes prices thousands of times per day. The "sale" label is often made up.

Here's the 10-second tool that shows the real price. 👇

**Post 2:**
CamelCamelCamel.com — free.

Paste any Amazon product URL. It shows you the complete price history going back years. Today's price vs. historical average vs. all-time low.

That "Was $89, Now $59" label? You'll see immediately whether $59 is a deal — or just the normal everyday price with a fake "was" number.

**Post 3:**
Before buying ANYWHERE online: Google Shopping.

Google → type product name → click "Shopping" tab → sort by Price: Low to High.

Same product. Every major US store. Shipping included. All at once.

Takes 90 seconds.

I found the same blood pressure monitor $15 cheaper at a medical supply retailer. In one search.

**Post 4:**
For any product you're not sure about: ask ChatGPT.

"Best blood pressure monitor under $70 for a 72-year-old with mild arthritis. Large buttons. Big display. Simple operation."

Three specific recommendations. Tailored to the exact situation. Pros and cons for each.

Then price-check those models on Google Shopping and CamelCamelCamel.

**Post 5:**
3 rules. Every online purchase:

1. Google Shopping first (90 sec)
2. CamelCamelCamel for Amazon items (2 min)
3. ChatGPT for the right product (3 min)

Total: 5 minutes. Savings: real money, every time.

"Look before you leap." — now I understand why.

Full system guide in bio. Series EP.26–30 complete 🎉
