# EP29 — AI IMAGE GENERATION PROMPTS
# Papago vs DeepL vs ChatGPT — Translation AI
# Updated: 2026-04-28

---

## IMAGE SLOT 1 — Intro / Blog Header (16:9)
Context: Elderly man reading letter with camera translation overlay

### Midjourney v6:
```
elderly asian american man (70s) holding a handwritten letter, smartphone hovering over the letter with translation text overlay visible on phone screen, warm home interior, soft natural lighting, sense of wonder and joy on his face, realistic photography style, 16:9 --ar 16:9 --v 6 --style raw
```

### DALL-E 3:
```
Photorealistic image: An elderly man (70s) holding a handwritten letter while his smartphone camera overlays translated text directly on the letter. His expression shows wonder and happiness. Warm, cozy home interior lighting. Horizontal 16:9. No brand logos.
```

### Stock Alternative:
- "senior man translating letter smartphone"
- "elderly person camera translation app"
- "grandfather overseas family letter"

---

## IMAGE SLOT 2 — Tech Concept (16:9)
Context: Three AI tools comparison visual

### Midjourney v6:
```
clean flat design infographic showing three smartphones side by side, left phone showing camera translation with text overlay, middle phone showing document upload interface, right phone showing chat conversation writing a letter, modern minimal design, blue and white color scheme, 16:9 --ar 16:9 --v 6
```

### DALL-E 3:
```
Clean modern infographic: Three smartphones side by side on white background. Left phone: camera translation app with text overlay on a document. Center phone: document translation progress bar. Right phone: AI chat writing a letter. Each phone labeled with a simple icon. Blue and white color palette. Horizontal 16:9.
```

---

## IMAGE SLOT 3 — Saying Image (16:9)
Context: "It's not what you say, it's how you say it"

### Midjourney v6:
```
vintage editorial illustration, two people silhouettes connected by speech bubbles morphing into hearts, communication across language barrier visual metaphor, warm gold and navy colors, bridge between two cultures, decorative americana style, no text, 16:9 --ar 16:9 --v 6
```

### DALL-E 3:
```
Editorial illustration: Two silhouette figures on opposite sides, connected by flowing speech bubbles that transform into glowing hearts in the middle. Visual metaphor for cross-language connection. Warm gold and deep blue colors. No text. Horizontal 16:9. Vintage Americana editorial style.
```

---

## VISUAL STORY PANELS (1:1 Square)

### Panel 1 — "Grandpa Bob Stumped by the English Letter!"
```
friendly cartoon illustration of a puzzled elderly man holding an open letter, question marks floating around his head, foreign language symbols visible on the letter, warm kitchen background, gentle humorous expression, educational cartoon style, square format --ar 1:1 --v 6
```

### Panel 2 — "Papago Translates It Instantly!"
```
cartoon illustration of a smartphone hovering over a letter, magical translation beams flowing from camera to letter, translated text appearing on top of original text, sparkle effects, joyful translation magic visual, warm colors, educational cartoon, square format --ar 1:1 --v 6
```

### Panel 3 — "Now We Can Connect Anywhere in the World!"
```
cartoon illustration of happy elderly man on video call or writing a letter, globe in background showing world connection, family connection across distance, flags representing different countries, warm and joyful colors, celebratory educational cartoon, square format --ar 1:1 --v 6
```

---

## AI ICON GRID (4 × 1:1 small squares)

### Icon 1 — Camera Translation (📷)
```
minimalist icon: camera lens with language characters A→文 inside lens, clean flat design, blue gradient, modern app icon style, 1:1 square
```

### Icon 2 — Voice Translator (🎤)
```
minimalist icon: microphone with speech bubble containing world globe, voice translation concept, clean modern design, purple and white, 1:1 square
```

### Icon 3 — Document Translation (📄)
```
minimalist icon: document page with arrows pointing between two language symbols, clean translation icon, teal and white, modern flat design, 1:1 square
```

### Icon 4 — Letter/Email Writing (✉️)
```
minimalist icon: envelope with pen and heart, letter writing concept, warm amber and white, clean friendly icon style, 1:1 square
```

---

## YOUTUBE THUMBNAIL SPEC

**Concept:** Magic camera reveal moment
- BACKGROUND: Dark navy
- LEFT: Phone camera hovering over English handwritten letter
- RIGHT: Same letter with Korean text floating on top (golden glow effect)
- CENTER ARROW: Bold yellow "→"
- TOP TEXT: "INSTANT TRANSLATION!" (bold white)
- BOTTOM: "AI Decoded for Seniors | EP.29" (gold on navy)
- EMOTION: Wonder/delight — not fear or confusion

**Alternative concept:** Split face reactions
- LEFT: Grandpa Bob confused, holding letter
- RIGHT: Grandpa Bob smiling, reading translated version on phone

---

## IMAGE SPECS

| Slot | Size | Format |
|---|---|---|
| Blog Headers (1,2,3) | 1200×630 | JPG |
| YouTube Thumbnail | 1280×720 | JPG |
| Story Panels (×3) | 1080×1080 | JPG/PNG |
| Icon Grid (×4) | 400×400 | PNG |
| Instagram Carousel | 1080×1080 | JPG |
| Instagram Story | 1080×1920 | JPG |

## ⚖️ COPYRIGHT NOTE
All generated images are original AI creations — no copyright issues.
Do not include real Papago, DeepL, or OpenAI logos in generated images.
For app screenshots: caption as "Screenshot: [App Name], [Date]"
