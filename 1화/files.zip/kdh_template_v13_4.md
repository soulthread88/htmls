# KPop Demon Hunters (케데헌) 템플릿 가이드 V13.0

## 🎯 필수 구성 요소

### ⚠️ CRITICAL: 제목 헤더 (반드시 포함!)
**모든 에피소드의 최상단에 반드시 포함해야 하는 제목 헤더**

```html
<!-- 제목 헤더 -->
<div style="text-align: center; margin-bottom: 40px; background-color: #000000; padding: 40px 20px; border-radius: 15px;">
  <h1 style="font-size: 42px; font-weight: 900; color: #ffffff; margin-bottom: 10px;"><span style="color: #ffd700;">🎵</span> KPop Demon Hunters <span style="color: #ffd700;">🎵</span></h1>
  <p style="font-size: 32px; font-weight: 700; color: #ffffff;">윤호와 함께하는 AI 이야기</p>
</div>
```

**위치**: 사자성어 섹션 바로 위, 콘텐츠의 최상단
**스타일**: 검정색 배경 (#000000), 흰색 텍스트 (#ffffff), 금색 이모지 (#ffd700)

---

## 📐 레이아웃 구조 (중요!)

### 전체 가로폭 비율
```
왼쪽 여백(15%) + 콘텐츠(54%) + 중간 여백(1%) + 사이드바(15%) + 오른쪽 여백(15%) = 100%
```

### HTML 구조
```html
<div class="kdh-blog-container">
  <div class="kdh-layout">
    <!-- 왼쪽 여백 15% -->
    <div class="kdh-left-margin"></div>
    
    <!-- 메인 콘텐츠 54% -->
    <div class="kdh-main-content">
      <div class="kdh-content">
        <!-- 콘텐츠 내용 -->
      </div>
    </div>
    
    <!-- 중간 여백 1% -->
    <div class="kdh-middle-margin"></div>
    
    <!-- 사이드바 15% -->
    <div class="kdh-sidebar">
      <!-- 사이드바 위젯들 -->
    </div>
    
    <!-- 오른쪽 여백 15% -->
    <div class="kdh-right-margin"></div>
  </div>
</div>
```

---

## 📊 핵심 스타일 규칙

### 1. 폰트 크기 및 간격
```css
body {
  font-size: 26px;
  line-height: 2.0;
}

.kdh-content {
  font-size: 26px;
  line-height: 2.0;
}

.kdh-content h2 {
  font-size: 42px;
  color: #003366;
  border-bottom: 4px solid #003366;
}

.kdh-content h3 {
  font-size: 32px;
  color: #003366;
  margin: 5px 0 5px 0;
}

.kdh-content p {
  margin-bottom: 20px;
  line-height: 2.0;
  font-size: 26px;
}
```

### 2. 색상 코드
- **고유명사**: `#ff1744` (빨간색)
- **제목 (h2, h3)**: `#003366` (진한 파란색)
- **강조 텍스트**: `#ff1744` (빨간색)
- **캡션**: `#555555` (회색), font-size: 22px
- **제목 헤더 이모지**: `#ffd700` (금색)
- **핑크 박스 배경**: `#ff69b4`, `#ff1493` (핑크 그라데이션)
- **핑크 박스 제목**: `#006b7d` (진한 청록색 - Dark Cyan)
- **핑크 박스 강조/고유명사**: `#000080` (진한 남색 - Navy)
- **키워드 제목**: `#006b7d` (진한 청록색)
- **키워드 배경**: `#006400` (진한 초록색)
- **키워드 글자**: `#ffffff` (흰색)

### 3. 사자성어 섹션
```css
.kdh-proverb-section {
  background: linear-gradient(135deg, #1a5490 0%, #0d3a6b 100%);
  padding: 50px;
}

.kdh-proverb-chinese, .kdh-proverb-korean {
  font-size: 48px;
}

.kdh-proverb-main-meaning, .kdh-proverb-detail {
  font-size: 28px;
  line-height: 1.8;
}
```

---

## 📋 고유명사 표기 규칙

### 1. 기본 원칙
- **모든 고유명사는 한글(영문) 형식**으로 작성
- **조사 연결**: 한글 다음의 조사는 한글 끝자와 붙여서 작성 (예: "케데헌을", "윤호가")
- **흰색 배경 본문**: 고유명사와 강조 부분은 **빨간색 bold체** (`.proper-name` 또는 `.emphasis-red` 클래스 사용)
- **노란색 박스(kdh-story-box) 내부**: 고유명사, 화자, 인용문, 강조 부분 모두 **빨간색 bold체** (`.emphasis-red` 클래스 사용)
- 색상: `#ff1744`
- 예: 루미(Rumi), 오드리(Audrey), 레이 아미(Rei Ami)

### 2. 본문(흰색 배경)에서의 표기
```html
<!-- 고유명사 -->
<p><span class="content-person-name">윤호</span>네 가족은 거실에 모여...</p>
<p>2026년은 <span class="emphasis-red">광복 81주년</span>을 맞는...</p>

<!-- 조사 연결 예시 -->
<p><span class="kdh-kph-name">케데헌(KPop Demon Hunters)</span>을 함께 봅니다.</p>
<p><span class="proper-name">윤호</span>가 설명했습니다.</p>
```

### 3. 노란색 박스 내부에서의 표기
```html
<div class="kdh-story-box">
  <!-- 모든 고유명사, 화자, 인용문, 강조 부분을 빨간색 bold로 -->
  <p><span class="emphasis-red">루미:</span> "저희가 지금 자유롭게..."</p>
  <p>"<span class="emphasis-red">2026년 8월 15일</span>"</p>
  <p>"<span class="emphasis-red">광복 81주년</span>을 기념하여"</p>
  <p><span class="emphasis-red">"Liberation, Liberation"</span></p>
  <p><span class="emphasis-red">"Never forget, Forever remember"</span></p>
</div>
```

### 4. 특수 고유명사
- **"오드리 누나"는 전체가 하나의 고유명사**
  - 표기: `오드리 누나(Audrey Nuna)`
  - 전체를 빨간색 bold체로 처리
  - HTML: `<span class="proper-name">오드리 누나(Audrey Nuna)</span>`

### 5. 캐릭터 이름 목록
- 루미(Rumi)
- 오드리(Audrey)
- 오드리 누나(Audrey Nuna) - 전체가 고유명사
- 아누비스(Anubis)
- 레이 아미(Rei Ami)
- 준(Joon)
- 태양(Taeyang)
- 민호(Minho)

### 6. 기타 고유명사
- 브랜드/회사: 애플(Apple), 픽사(Pixar), 디즈니(Disney)
- 작품명: 해리포터(Harry Potter)
- 인명: 스티브 잡스(Steve Jobs), 월트 디즈니(Walt Disney)
- 장소: 광화문(Gwanghwamun)

---

## 🎨 사자성어 표기 규칙

### 1. 불요불굴(不撓不屈) 표기
- **빨간색 bold체** 필수 (`#ff1744`)
- HTML: `<span class="emphasis-red">불요불굴(不撓不屈)</span>`
- 모든 등장 시 일관되게 적용

### 2. 사자성어 구성 순서
불요불굴의 경우:
1. **不 (아니)** - 부정의 의미
2. **撓 (휘다)** - 굽혀지는 것
3. **不 (아니)** - 부정의 의미
4. **屈 (굽히다)** - 꺾이는 것

```html
<div class="kdh-info-box">
  <h3>📖 불요불굴 (不撓不屈)</h3>
  
  <p><strong>不:</strong> 아니 불</p>
  <p><strong>撓:</strong> 휠 요</p>
  <p><strong>不:</strong> 아니 불</p>
  <p class="kdh-group-end"><strong>屈:</strong> 굽힐 굴</p>
  
  <p><span class="emphasis-red">굽혀지지도 꺾이지도 않는다</span></p>
  <p class="kdh-group-end"></p>
  
  <p>어떤 어려움에도 꺾이지 않는 정신</p>
  <p>끝까지 포기하지 않는 의지</p>
</div>
```

---

## 💬 영어 속담 표기 규칙 (업데이트!)

### 1. 속담 해석 방식
- 직역보다는 **한국 속담으로 의역**
- 괄호 사용: `(한국 속담)`

### 2. Quote Box 스타일 (중요 변경사항!)
```css
.kdh-quote-box {
  background: linear-gradient(135deg, #003366 0%, #0d3a6b 100%);
  padding: 50px;
}

.kdh-quote-english {
  font-size: 30px;  /* 28px → 30px (2pt 증가) */
  color: #ffffff;
  font-family: Helvetica, Arial, sans-serif;
  font-style: italic;  /* 이탤릭체 추가 */
}

.kdh-quote-korean {
  font-size: 26px;  /* 24px → 26px (2pt 증가) */
  color: #ffd700;
  line-height: 2.0;
  font-style: italic;  /* 이탤릭체 추가 */
}

.kdh-quote-source {
  font-size: 22px;
  color: #aaaaaa;
  font-style: italic;  /* 이탤릭체 */
}
```

### 3. 예시 (Source 추가!)
```html
<div class="kdh-quote-box">
  <p class="kdh-quote-english"><em>"We honor those who fought<br>for our freedom."</em></p>
  <p class="kdh-quote-korean"><em>우리의 자유를 위해 싸운 분들을<br>기립니다.</em></p>
  <p class="kdh-quote-source"><em>(Source: 여섯 명의 다짐)</em></p>
</div>

<div class="kdh-quote-box">
  <p class="kdh-quote-english"><em>"Freedom is the oxygen<br>of the soul."</em></p>
  <p class="kdh-quote-korean"><em>자유는 영혼의 산소다.</em></p>
  <p class="kdh-quote-source"><em>(Source: 모세 다윤)</em></p>
</div>
```

**중요**: 
- 영어와 한글 모두 `<em>` 태그로 이탤릭체 처리
- Source는 한글 해석 다음 줄에 `(Source: xxxx)` 형식으로 표기
- Source도 이탤릭체로 처리

---

## 📦 Box 스타일 사용 규칙

### 1. 노란색 박스 (kdh-story-box)
- **용도**: 전투 상황, 스토리 설명, 역사적 사례, 기자회견
- **배경**: 노란색 그라데이션 `linear-gradient(135deg, #f9e79f 0%, #f8e48f 100%)`
- **텍스트**: 진한 파란색 (#003366)
- **고유명사 및 강조**: 빨간색 bold체 (#ff1744) - `.emphasis-red` 클래스 사용
- **Padding**: 50px
- **폰트**: 26px, line-height 2.0

**중요**: 노란색 박스 내에서는 모든 고유명사, 화자 표시, 인용문, 강조할 부분을 **빨간색 bold체**로 통일합니다.

```html
<div class="kdh-story-box">
  <h3>📢 기자회견</h3>
  
  <p>"여러분께 특별한 소식을 알려드립니다."</p>
  <p class="kdh-story-group-end"></p>
  
  <p>"<span class="emphasis-red">2026년 8월 15일</span>"</p>
  <p class="kdh-story-group-end"></p>
  
  <p>"<span class="emphasis-red">광복 81주년</span>을 기념하여"</p>
  <p class="kdh-story-group-end"></p>
  
  <p>"<span class="emphasis-red">헌트릭스</span>와 <span class="emphasis-red">사자 보이즈</span>가"</p>
  <p class="kdh-story-group-end"></p>
  
  <p>곡 제목: <span class="emphasis-red">"Liberation (해방)"</span></p>
</div>
```

### 2. 핑크색 박스 (kdh-info-box)
- **용도**: 사자성어 분석, 교훈, 방법론, 감동의 순간, 애니메이션 설명
- **배경**: 핑크색 그라데이션 `linear-gradient(135deg, #ff69b4 0%, #ff1493 100%)`
- **제목(h3)**: 진한 청록색 (#006b7d) - Dark Cyan
- **본문 텍스트**: 진한 청록색 (#003d4d)
- **강조/고유명사**: 진한 남색 (#000080) - Navy
- **Padding**: 50px
- **폰트**: 26px, line-height 2.0

**중요**: 
- 핑크색 박스의 소제목은 진한 청록색(#006b7d) 사용
- 본문 내 강조와 고유명사는 진한 남색(#000080) 사용
- 조사 연결: "케데헌(KPop Demon Hunters)이란?" (괄호 앞 한글에 조사 붙임)

```html
<div class="kdh-info-box">
  <h3>🎵 <span class="kdh-kph-name">케데헌(KPop Demon Hunters)</span>이란?</h3>
  
  <p>한국계 미국인 두 명과 한국인 한 명의 <strong>KPop</strong> 가수들이</p>
  <p class="kdh-group-end"><strong>악마 사냥꾼(Demon Hunters)</strong>이 되어</p>
  
  <p><strong>음악으로 악마(Demon)들</strong>을 물리치는</p>
  <p class="kdh-group-end">애니메이션 영화입니다.</p>
</div>
```

**CSS 예시**:
```css
.kdh-info-box {
  background: linear-gradient(135deg, #ff69b4 0%, #ff1493 100%);
  color: #003d4d;
}

.kdh-info-box h3 {
  color: #006b7d;  /* 진한 청록색 */
}

.kdh-info-box strong,
.kdh-info-box .proper-name,
.kdh-info-box .kdh-kph-name {
  color: #000080;  /* 진한 남색 */
}
```

### 3. 진한 청색 박스 (kdh-golden-profile)
- **용도**: 캐릭터 프로필, 가족 경험, 노래 정보, 역사 정보, 독립운동가 소개
- **배경**: 진한 청색 그라데이션 `linear-gradient(135deg, #003366 0%, #0d3a6b 100%)`
- **텍스트**: 흰색 (#ffffff)
- **강조**: 금색 (#ffd700) 또는 노란색 (#ffffff)
- **Padding**: 50px
- **폰트**: 26px, line-height 2.0

```html
<div class="kdh-golden-profile">
  <h3>광복절 (光復節)</h3>

  <p><strong style="color: #ffffff;">의미</strong></p>
  <p class="kdh-group-end">光 (빛 광) + 復 (회복할 복) = 빛을 되찾은 날</p>
  
  <p><strong style="color: #ffd700;">역사</strong></p>
  <p class="kdh-group-end">1945년 8월 15일 / 일본 식민 지배에서 해방</p>
  
  <p><strong style="color: #ffd700;">2026년</strong></p>
  <p>광복 81주년 / 81년 동안의 발전</p>
</div>
```

---

## ✍️ 맞춤법/문법 검사기 섹션 (NEW!)

댓글 작성 전 맞춤법을 체크할 수 있는 도구를 제공합니다.

### 1. 위치
- 댓글 섹션 바로 위에 배치
- 키워드 섹션과 댓글 섹션 사이

### 2. 구성 요소
- **한국어 맞춤법 검사기**: 나라 맞춤법 검사기 (https://nara-speller.co.kr/old_speller/)
- **영어 맞춤법 검사기**: Grammarly (https://app.grammarly.com/)

### 3. HTML 구조
```html
<!-- 맞춤법/문법 검사기 섹션 -->
<div class="kdh-grammar-checker-section">
  <h2 data-ke-size="size26">✍️ 댓글 작성 전 맞춤법 체크</h2>

  <!-- 한국어 맞춤법 검사기 -->
  <div class="kdh-grammar-box">
    <h3>🇰🇷 한국어 맞춤법/문법 검사기</h3>
    <div class="kdh-grammar-iframe-wrapper">
      <iframe src="https://nara-speller.co.kr/old_speller/" 
              title="한국어 맞춤법 검사기"
              frameborder="0"
              allowfullscreen></iframe>
    </div>
    <p class="kdh-grammar-desc">댓글을 작성한 후 위 검사기에서 맞춤법을 확인하고 복사하여 댓글란에 붙여넣으세요.</p>
  </div>

  <!-- 영어 맞춤법 검사기 -->
  <div class="kdh-grammar-box">
    <h3>🇺🇸 영어 맞춤법/문법 검사기 (Grammarly)</h3>
    <div class="kdh-grammar-iframe-wrapper">
      <iframe src="https://app.grammarly.com/" 
              title="Grammarly 영어 문법 검사기"
              frameborder="0"
              allowfullscreen></iframe>
    </div>
    <p class="kdh-grammar-desc">영어 댓글 작성 시 Grammarly에서 문법을 확인하고 수정된 내용을 복사하세요.</p>
  </div>
</div>
```

### 4. CSS 스타일
```css
/* 맞춤법/문법 검사기 섹션 */
.kdh-grammar-checker-section {
  margin: 50px 0;
  padding: 30px;
  background: #f8f9fa;
  border-radius: 10px;
}

.kdh-grammar-checker-section h2 {
  color: #003366;
  margin-bottom: 30px;
  padding-bottom: 15px;
  border-bottom: 3px solid #006b7d;
}

.kdh-grammar-box {
  background: #ffffff;
  border-radius: 10px;
  padding: 25px;
  margin-bottom: 30px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.kdh-grammar-box:last-child {
  margin-bottom: 0;
}

.kdh-grammar-box h3 {
  color: #006b7d;
  font-size: 20px;
  margin: 0 0 15px 0;
  padding-bottom: 10px;
  border-bottom: 2px solid #e0e0e0;
}

.kdh-grammar-iframe-wrapper {
  width: 100%;
  aspect-ratio: 16 / 9;  /* 16:9 비율 */
  background: #f5f5f5;
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 15px;
  border: 2px solid #e0e0e0;
}

.kdh-grammar-iframe-wrapper iframe {
  width: 100%;
  height: 100%;
  border: none;
}

.kdh-grammar-desc {
  color: #666;
  font-size: 14px;
  line-height: 1.6;
  margin: 0;
  padding: 10px 15px;
  background: #fff3cd;
  border-left: 4px solid #ffc107;
  border-radius: 4px;
}
```

### 5. 디자인 특징
- **16:9 비율**: `aspect-ratio: 16 / 9` 사용하여 자동 비율 유지
- **반응형 디자인**: 화면 크기에 따라 자동 조정
- **시각적 구분**: 회색 배경으로 섹션 구분
- **안내 메시지**: 노란색 박스로 사용법 명확하게 안내

### 6. 사용 방법
1. 댓글을 먼저 작성
2. 해당 언어의 검사기에 붙여넣기
3. 맞춤법/문법 확인 및 수정
4. 수정된 내용을 복사
5. 댓글란에 붙여넣기 후 제출

---

## 🗨️ 댓글 섹션 (NEW!)

### YouTube 스타일 댓글 시스템

**위치**: 키워드 섹션과 다음 편 예고 사이

```html
<!-- 댓글 섹션 -->
<div class="kdh-comments-section">
  <div class="kdh-comments-header">
    <h3>댓글 <span class="kdh-comments-count">0</span>개</h3>
    <div class="kdh-comments-sort">
      <button class="kdh-sort-btn active">최신순</button>
      <button class="kdh-sort-btn">인기순</button>
    </div>
  </div>

  <div class="kdh-comment-input-section">
    <div class="kdh-comment-avatar">
      <img src="..." alt="사용자">
    </div>
    <div class="kdh-comment-input-wrapper">
      <textarea class="kdh-comment-input" placeholder="댓글 추가..."></textarea>
      <div class="kdh-comment-actions">
        <button class="kdh-comment-btn kdh-cancel-btn">취소</button>
        <button class="kdh-comment-btn kdh-submit-btn">댓글</button>
      </div>
    </div>
  </div>

  <!-- 댓글 목록 -->
  <div class="kdh-comments-list">
    <div class="kdh-comment-item">
      <div class="kdh-comment-avatar">
        <img src="..." alt="사용자">
      </div>
      <div class="kdh-comment-content">
        <div class="kdh-comment-header">
          <span class="kdh-comment-author">@username</span>
          <span class="kdh-comment-time">방금 전</span>
        </div>
        <div class="kdh-comment-text">
          댓글 내용
        </div>
        <div class="kdh-comment-actions-bar">
          <button class="kdh-comment-action-btn">
            <span class="kdh-like-icon">👍</span>
            <span class="kdh-like-count">0</span>
          </button>
          <button class="kdh-comment-action-btn">
            <span class="kdh-dislike-icon">👎</span>
          </button>
          <button class="kdh-comment-action-btn">답글</button>
          <button class="kdh-comment-action-btn">•••</button>
        </div>
      </div>
    </div>
  </div>
</div>
```

---

## 📱 사이드바 구조 (업데이트!)

### 사이드바 위젯 순서 (위에서 아래로)
1. 📂 카테고리
2. 📅 달력 (국가 공휴일 표시)
3. 📝 최근 글
4. 💬 최근 댓글
5. 광고 1~10 (16:9 비율, 총 10개)
6. 🔑 키워드
7. 🏷️ 태그

### 1. 카테고리
```html
<div class="kdh-sidebar-widget">
  <h3>📂 카테고리</h3>
  <ul class="kdh-category-list">
    <li><a href="#">케데헌 시리즈 (12)</a></li>
    <li><a href="#">시니어 영어 학습 (24)</a></li>
    <li><a href="#">AI 활용법 (18)</a></li>
    <li><a href="#">가족 이야기 (15)</a></li>
  </ul>
</div>
```

### 2. 달력 (국가 공휴일 표시!)
```html
<div class="kdh-sidebar-widget">
  <h3>📅 달력</h3>
  <div class="kdh-calendar">
    <div class="kdh-calendar-header">
      <button class="kdh-calendar-nav">◀</button>
      <span class="kdh-calendar-title">2025년 12월</span>
      <button class="kdh-calendar-nav">▶</button>
    </div>
    <table class="kdh-calendar-table">
      <thead>
        <tr>
          <th>일</th><th>월</th><th>화</th><th>수</th><th>목</th><th>금</th><th>토</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td class="kdh-cal-day">1</td>
          <td class="kdh-cal-day">2</td>
          <td class="kdh-cal-day kdh-cal-today">3</td>
          <td class="kdh-cal-day">4</td>
          <td class="kdh-cal-day">5</td>
          <td class="kdh-cal-day">6</td>
          <td class="kdh-cal-day">7</td>
        </tr>
        <!-- ... -->
        <tr>
          <td class="kdh-cal-day">22</td>
          <td class="kdh-cal-day">23</td>
          <td class="kdh-cal-day">24</td>
          <td class="kdh-cal-day kdh-cal-holiday" title="성탄절">25</td>
          <td class="kdh-cal-day">26</td>
          <td class="kdh-cal-day">27</td>
          <td class="kdh-cal-day">28</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
```

**달력 스타일**:
- `.kdh-cal-today`: 오늘 날짜 (파란 배경, 흰 글씨)
- `.kdh-cal-holiday`: 공휴일 (빨간 글씨, 굵게)

### 3. 최근 글
```html
<div class="kdh-sidebar-widget">
  <h3>📝 최근 글</h3>
  <ul class="kdh-recent-posts">
    <li>
      <a href="#">시니어를 위한 AI 영어 학습법</a>
      <span class="kdh-post-date">2025.11.15</span>
    </li>
    <li>
      <a href="#">케데헌으로 배우는 영어 표현 10선</a>
      <span class="kdh-post-date">2025.11.12</span>
    </li>
  </ul>
</div>
```

### 4. 최근 댓글 (NEW!)
```html
<div class="kdh-sidebar-widget">
  <h3>💬 최근 댓글</h3>
  <ul class="kdh-recent-comments">
    <li>
      <div class="kdh-comment-author-name">김철수</div>
      <div class="kdh-comment-preview">정말 감동적인 이야기네요...</div>
      <div class="kdh-comment-date">2025.12.03</div>
    </li>
    <li>
      <div class="kdh-comment-author-name">이영희</div>
      <div class="kdh-comment-preview">손자와 할아버지가 함께...</div>
      <div class="kdh-comment-date">2025.12.02</div>
    </li>
  </ul>
</div>
```

### 5. 광고 영역 (16:9 비율!)
```html
<!-- 광고 1-10 -->
<div class="kdh-ad-box">
  <p>광고 영역 1<br />(300x250)</p>
</div>
<!-- 총 10개 반복 -->
```

**중요**: 광고 박스는 `aspect-ratio: 16 / 9;`를 사용하여 16:9 비율 유지

### 6. 키워드
```html
<div class="kdh-sidebar-widget kdh-keyword-widget">
  <h3>🔑 키워드</h3>
  <div class="kdh-keyword-list">
    <a href="#" class="kdh-keyword-tag">케데헌</a>
    <a href="#" class="kdh-keyword-tag">영어학습</a>
    <a href="#" class="kdh-keyword-tag">시니어</a>
    <a href="#" class="kdh-keyword-tag">넷플릭스</a>
    <a href="#" class="kdh-keyword-tag">KPop</a>
    <a href="#" class="kdh-keyword-tag">할아버지</a>
    <a href="#" class="kdh-keyword-tag">AI</a>
    <a href="#" class="kdh-keyword-tag">가족</a>
    <a href="#" class="kdh-keyword-tag">음악</a>
    <a href="#" class="kdh-keyword-tag">애니메이션</a>
    <a href="#" class="kdh-keyword-tag">세대공감</a>
    <a href="#" class="kdh-keyword-tag">교육</a>
  </div>
</div>
```

**키워드 스타일**:
- 제목: 진한 청록색 (#006b7d)
- 배경: 진한 초록색 (#006400)
- 글자: 흰색 (#ffffff) - 진한 초록색과 최고 대조
- 수량: 사이드바 가로폭을 가득 채우는 수량으로 조정

**CSS**:
```css
.kdh-keyword-widget h3 {
  color: #006b7d;
  border-bottom-color: #006b7d;
}

.kdh-keyword-tag {
  background: #006400;
  color: #ffffff;
  padding: 6px 12px;
  border-radius: 15px;
}
```

### 7. 태그
```html
<div class="kdh-sidebar-widget">
  <h3>🏷️ 인기 태그</h3>
  <div class="kdh-tag-cloud">
    <a href="#" style="font-size: 16px;">일기일회</a>,
    <a href="#" style="font-size: 20px;">세대공감</a>,
    <a href="#" style="font-size: 14px;">애니메이션</a>,
    <a href="#" style="font-size: 18px;">음악</a>,
    <a href="#" style="font-size: 15px;">협력</a>,
    <a href="#" style="font-size: 19px;">우정</a>,
    <a href="#" style="font-size: 17px;">용기</a>,
    <a href="#" style="font-size: 16px;">문화</a>,
    <a href="#" style="font-size: 15px;">영어</a>,
    <a href="#" style="font-size: 18px;">학습</a>,
    <a href="#" style="font-size: 14px;">가족</a>,
    <a href="#" style="font-size: 17px;">추억</a>
  </div>
</div>
```

**태그 스타일**:
- 각 태그 뒤에 쉼표(,) 추가
- 수량: 사이드바 가로폭을 가득 채우는 수량으로 조정
- 폰트 크기는 인기도에 따라 14px~20px 사이에서 조정

---

## 🎯 일관성 체크리스트

### 에피소드 작성 시 필수 확인사항
- [ ] **레이아웃**: 15% + 54% + 1% + 15% + 15% 구조인가?
- [ ] **제목 헤더가 최상단에 있는가?** (검정 배경, 흰색 텍스트, 금색 이모지)
- [ ] **흰색 배경 본문**: 모든 고유명사와 강조 부분이 빨간색 bold인가?
- [ ] **조사 연결**: 한글(영문) 다음 조사가 한글에 붙어있는가?
- [ ] **노란색 박스(kdh-story-box)**: 모든 고유명사, 화자, 인용문, 강조 부분이 빨간색 bold인가?
- [ ] "오드리 누나(Audrey Nuna)"는 전체가 빨간색 bold인가?
- [ ] 불요불굴(不撓不屈)이 빨간색 bold인가?
- [ ] **Quote Box**: 영어와 한글이 이탤릭체인가? (font-size 2pt 증가)
- [ ] **Quote Box**: Source가 한글 다음 줄에 `(Source: xxxx)` 형식으로 있는가?
- [ ] 사자성어 한자 순서가 정확한가?
- [ ] 브랜드/작품명/장소가 한글(영문) 형식인가?
- [ ] 영어 속담이 한국 속담으로 의역되었는가?
- [ ] 각 박스의 용도가 맞게 사용되었는가?
- [ ] 모든 박스의 padding이 50px인가?
- [ ] 텍스트 크기가 26px, line-height 2.0인가?
- [ ] 색상 코드가 통일되었는가? (#ff1744, #003366 등)
- [ ] **맞춤법/문법 검사기**가 댓글 섹션 위에 있는가? (한국어, 영어 각 1개, 16:9 비율)
- [ ] **댓글 섹션**이 키워드와 다음 편 예고 사이에 있는가?
- [ ] **댓글**이 7개 있고, 사이드바에 최근 댓글 3개가 표시되는가?
- [ ] **사이드바 순서**: 카테고리 → 달력 → 최근 글 → 최근 댓글 → 광고(10개) → 키워드 → 태그
- [ ] **달력**에 오늘 날짜와 공휴일이 표시되어 있는가?
- [ ] **광고 박스**가 16:9 비율인가?

---

## 🔧 주요 CSS 클래스

### 텍스트 스타일
- `.proper-name` - 고유명사 (빨간색 #ff1744 bold)
- `.content-person-name` - 일반 인물명 (빨간색 #ff1744 bold)
- `.emphasis-red` - 강조 텍스트 (빨간색 #ff1744 bold)
- `.emphasis-yellow` - 강조 텍스트 (금색 #ffd700 bold)
- `.kdh-kph-name` - 작품명 (빨간색 #ff1744 bold)

### 박스 스타일
- `.kdh-story-box` - 노란색 박스 (전투, 스토리, 기자회견)
- `.kdh-info-box` - 핑크색 박스 (사자성어, 교훈, 감동의 순간)
- `.kdh-golden-profile` - 진한 청색 박스 (프로필, 경험, 역사 정보)
- `.kdh-quote-box` - 인용구 박스 (진한 청색, 이탤릭체)
- `.kdh-next-section` - 다음 편 예고 박스 (노란색)

### 그룹 종료
- `.kdh-story-group-end` - 노란색 박스 그룹 종료 (margin-bottom: 30px)
- `.kdh-group-end` - 핑크색/청색 박스 그룹 종료 (margin-bottom: 30px)

### 레이아웃
- `.kdh-left-margin` - 왼쪽 여백 (15%)
- `.kdh-main-content` - 메인 콘텐츠 (54%)
- `.kdh-middle-margin` - 중간 여백 (1%)
- `.kdh-sidebar` - 사이드바 (15%)
- `.kdh-right-margin` - 오른쪽 여백 (15%)

### 댓글
- `.kdh-grammar-checker-section` - 맞춤법 검사기 전체 섹션
- `.kdh-grammar-box` - 개별 검사기 박스 (한국어/영어)
- `.kdh-grammar-iframe-wrapper` - iframe 래퍼 (16:9 비율)
- `.kdh-grammar-desc` - 사용 안내 메시지
- `.kdh-comments-section` - 댓글 섹션 전체
- `.kdh-comment-input` - 댓글 입력창
- `.kdh-comment-item` - 개별 댓글
- `.kdh-comment-action-btn` - 댓글 액션 버튼 (좋아요, 싫어요, 답글)

### 사이드바
- `.kdh-sidebar-widget` - 사이드바 위젯 박스
- `.kdh-calendar` - 달력
- `.kdh-cal-today` - 오늘 날짜
- `.kdh-cal-holiday` - 공휴일
- `.kdh-ad-box` - 광고 박스 (16:9 비율)

---

## 📝 완전한 템플릿 구조

### 기본 HTML 구조
```html
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KPop Demon Hunters - Episode [번호]</title>
  <style>
    /* CSS 스타일 */
  </style>
</head>
<body>

<div class="kdh-blog-container">
  <div class="kdh-layout">
    <!-- 왼쪽 여백 15% -->
    <div class="kdh-left-margin"></div>
    
    <!-- 메인 콘텐츠 54% -->
    <div class="kdh-main-content">
      <div class="kdh-content">

        <!-- ⚠️ 필수: 제목 헤더 -->
        <div style="text-align: center; margin-bottom: 40px; background-color: #000000; padding: 40px 20px; border-radius: 15px;">
          <h1 style="font-size: 42px; font-weight: 900; color: #ffffff; margin-bottom: 10px;"><span style="color: #ffd700;">🎵</span> KPop Demon Hunters <span style="color: #ffd700;">🎵</span></h1>
          <p style="font-size: 32px; font-weight: 700; color: #ffffff;">윤호와 함께하는 AI 이야기</p>
        </div>

        <!-- 사자성어 섹션 -->
        <div class="kdh-proverb-section">
          <div class="kdh-proverb-chinese">[사자성어]<br>([한자])</div>
          <div class="kdh-proverb-main-meaning">[의미]</div>
          <div class="kdh-proverb-detail">[설명]</div>
        </div>

        <!-- 에피소드 제목 -->
        <h2>🎬 Episode [번호]: [제목]</h2>
        
        <!-- 콘텐츠 -->
        
        <!-- 키워드 섹션 -->
        <div class="kdh-related-posts" style="background: #e8f5e9; border: 2px solid #ff1493; margin: 40px 0;">
          <h3 style="color: #2e7d32; border-bottom: 2px solid #ff1493;">🔑 이번 편 주요 키워드</h3>
          <div style="display: flex; flex-wrap: wrap; gap: 10px; margin-top: 15px;">
            <span style="display: inline-block; background: #ff1493; color: #ffffff; padding: 8px 16px; border-radius: 20px; font-size: 16px; font-weight: 700;">키워드1</span>
            <span style="display: inline-block; background: #ff1493; color: #ffffff; padding: 8px 16px; border-radius: 20px; font-size: 16px; font-weight: 700;">키워드2</span>
          </div>
        </div>
        
        <!-- 댓글 섹션 -->
        <div class="kdh-comments-section">
          <!-- 댓글 내용 -->
        </div>
        
        <!-- 다음 편 예고 -->
        <div class="kdh-next-section">
          <h2>💡 다음 편 예고</h2>
          <p>다음 이야기 내용...</p>
          <p style="margin-top: 30px; font-size: 28px;"><strong>👉 다음 편: [제목]</strong></p>
          <p style="font-size: 24px;"><strong>Ep.[번호]에서 계속됩니다</strong></p>
        </div>

      </div>
    </div>

    <!-- 중간 여백 1% -->
    <div class="kdh-middle-margin"></div>

    <!-- 사이드바 15% -->
    <div class="kdh-sidebar">
      <!-- 1. 카테고리 -->
      <!-- 2. 달력 -->
      <!-- 3. 최근 글 -->
      <!-- 4. 최근 댓글 -->
      <!-- 5. 광고 1~10 -->
      <!-- 6. 키워드 -->
      <!-- 7. 태그 -->
    </div>
    
    <!-- 오른쪽 여백 15% -->
    <div class="kdh-right-margin"></div>
  </div>
</div>

</body>
</html>
```

---

## 버전 정보
- **Version**: 13.4
- **Last Updated**: 2025-12-03
- **Changes**: 
  - ⚠️ **맞춤법/문법 검사기 추가**: 댓글 섹션 위에 한국어/영어 검사기 배치
  - 한국어 맞춤법 검사기 (나라 맞춤법 검사기) - 16:9 비율 iframe
  - 영어 맞춤법 검사기 (Grammarly) - 16:9 비율 iframe
  - 사용 안내 메시지 (노란색 박스)
  - 메인 제목 이모지 변경: 🎵 → ⚡
  - 소제목 이모지들 업데이트 (더 멋있는 마크로)
  - 댓글 7개 추가 + 사이드바 최근 댓글 3개 연동
- **Previous Version**: 13.3
