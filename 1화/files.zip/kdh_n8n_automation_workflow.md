# KPop Demon Hunters 블로그 자동화 워크플로우 (n8n)

## 📋 전체 프로세스 개요

이 자동화 시스템은 **Claude → GPT Chat → SUNO → Tistory** 순서로 진행되며, 총 4단계로 구성됩니다.

```
[1단계] Claude로 HTML 생성
    ↓
[2단계] GPT Chat로 동요 가사/스타일 생성
    ↓
[3단계] SUNO로 MP3 생성
    ↓
[4단계] Tistory에 자동 발행
```

---

## 🔧 n8n 워크플로우 상세 설계

### 🎯 Node 1: Trigger (Manual / Schedule)
**Type**: Manual Trigger 또는 Schedule Trigger

**설정**:
- Manual: 수동으로 워크플로우 시작
- Schedule: 매주 특정 요일/시간에 자동 실행

**Output**: 
```json
{
  "episodeNumber": "02",
  "episodeTopic": "세 명의 사냥꾼들",
  "targetFolder": "C:\\ai\\ai가 뭐야, 윤호야?"
}
```

---

### 📝 Node 2: Claude API - HTML 생성
**Type**: HTTP Request (POST)

**Purpose**: Claude API를 통해 에피소드 HTML 생성

**Configuration**:
```json
{
  "method": "POST",
  "url": "https://api.anthropic.com/v1/messages",
  "authentication": "headerAuth",
  "headers": {
    "anthropic-version": "2023-06-01",
    "content-type": "application/json"
  },
  "body": {
    "model": "claude-sonnet-4-20250514",
    "max_tokens": 8000,
    "messages": [
      {
        "role": "user",
        "content": "템플릿 v13.3을 사용하여 케데헌 Episode {{$node[\"Trigger\"].json[\"episodeNumber\"]}} '{{$node[\"Trigger\"].json[\"episodeTopic\"]}}'에 대한 HTML 파일을 생성해주세요."
      }
    ]
  }
}
```

**Notes**:
- Anthropic API Key 필요 (Environment Variable로 저장)
- 템플릿 파일은 미리 Claude에게 제공되어야 함

---

### 💾 Node 3: Save HTML to File
**Type**: Write Binary File

**Purpose**: 생성된 HTML을 지정 폴더에 저장

**Configuration**:
```json
{
  "fileName": "kdh_ep{{$node[\"Trigger\"].json[\"episodeNumber\"]}}_tistory.html",
  "filePath": "{{$node[\"Trigger\"].json[\"targetFolder\"]}}\\kdh_ep{{$node[\"Trigger\"].json[\"episodeNumber\"]}}_tistory.html",
  "data": "={{$node[\"Claude API\"].json[\"content\"][0][\"text\"]}}"
}
```

**Windows Path 예시**: `C:\ai\ai가 뭐야, 윤호야?\kdh_ep02_tistory.html`

---

### 🎵 Node 4: GPT Chat - 동요 주제 생성
**Type**: OpenAI (GPT Chat)

**Purpose**: 에피소드 주제에 맞는 동요 컨셉 생성

**Configuration**:
```json
{
  "model": "gpt-4",
  "messages": [
    {
      "role": "system",
      "content": "당신은 어린이 동요 작곡가입니다. 주제에 맞는 재미있고 교육적인 동요 주제를 만들어주세요."
    },
    {
      "role": "user",
      "content": "케데헌 에피소드 '{{$node[\"Trigger\"].json[\"episodeTopic\"]}}'에 어울리는 동요 주제를 제안해주세요."
    }
  ]
}
```

---

### 🎼 Node 5: GPT Chat - 가사 작성
**Type**: OpenAI (GPT Chat)

**Purpose**: 동요 가사 작성

**Configuration**:
```json
{
  "model": "gpt-4",
  "messages": [
    {
      "role": "system",
      "content": "당신은 어린이 동요 작사가입니다. 한국어와 영어를 섞어 가사를 작성해주세요."
    },
    {
      "role": "user",
      "content": "주제: {{$node[\"GPT Chat - 동요 주제\"].json[\"choices\"][0][\"message\"][\"content\"]}}\n\n위 주제로 2-3분 분량의 동요 가사를 작성해주세요. 한국어 80%, 영어 20% 비율로 섞어주세요."
    }
  ]
}
```

---

### 🎨 Node 6: GPT Chat - 스타일 작성 (영어)
**Type**: OpenAI (GPT Chat)

**Purpose**: SUNO용 영어 스타일 태그 생성

**Configuration**:
```json
{
  "model": "gpt-4",
  "messages": [
    {
      "role": "system",
      "content": "You are a music style expert. Generate music style tags in English for SUNO AI."
    },
    {
      "role": "user",
      "content": "Topic: {{$node[\"GPT Chat - 동요 주제\"].json[\"choices\"][0][\"message\"][\"content\"]}}\n\nGenerate music style tags in English (e.g., 'upbeat pop, children's song, educational, playful, Korean K-pop influence')"
    }
  ]
}
```

**Expected Output Example**: 
```
upbeat pop, children's song, educational, playful, Korean K-pop influence, acoustic guitar, cheerful melody
```

---

### 🔄 Node 7: Set Variables
**Type**: Set

**Purpose**: 가사와 스타일을 변수로 저장

**Configuration**:
```json
{
  "values": {
    "lyrics": "={{$node[\"GPT Chat - 가사 작성\"].json[\"choices\"][0][\"message\"][\"content\"]}}",
    "style": "={{$node[\"GPT Chat - 스타일 작성\"].json[\"choices\"][0][\"message\"][\"content\"]}}",
    "episodeNumber": "={{$node[\"Trigger\"].json[\"episodeNumber\"]}}"
  }
}
```

---

### 🎵 Node 8: SUNO API - 동요 생성
**Type**: HTTP Request (POST) + Webhook (결과 수신)

**⚠️ 중요**: SUNO는 공식 API가 제한적이므로, 다음 방법 중 선택:

#### 방법 1: SUNO 비공식 API 사용
```json
{
  "method": "POST",
  "url": "https://suno-api.example.com/generate",
  "body": {
    "lyrics": "={{$node[\"Set Variables\"].json[\"lyrics\"]}}",
    "style": "={{$node[\"Set Variables\"].json[\"style\"]}}",
    "title": "케데헌 Episode {{$node[\"Set Variables\"].json[\"episodeNumber\"]}} 동요"
  }
}
```

#### 방법 2: Browser Automation (Puppeteer/Selenium)
n8n의 **Execute Command** 노드로 Python/Node.js 스크립트 실행:

```python
# suno_automation.py
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import sys

def create_suno_song(lyrics, style, output_path):
    driver = webdriver.Chrome()
    
    # 1. SUNO 웹사이트 열기
    driver.get("https://suno.com")
    time.sleep(3)
    
    # 2. 로그인 (세션 저장 사용 권장)
    # ... 로그인 로직 ...
    
    # 3. Lyrics 입력
    lyrics_box = driver.find_element(By.ID, "lyrics-input")
    lyrics_box.send_keys(lyrics)
    
    # 4. Style 입력
    style_box = driver.find_element(By.ID, "style-input")
    style_box.send_keys(style)
    
    # 5. Create 버튼 클릭
    create_btn = driver.find_element(By.XPATH, "//button[text()='Create']")
    create_btn.click()
    
    # 6. 생성 완료 대기 (최대 5분)
    time.sleep(180)
    
    # 7. 다운로드 버튼 클릭
    download_btn = driver.find_element(By.XPATH, "//button[contains(text(), 'Download')]")
    download_btn.click()
    time.sleep(10)
    
    # 8. 다운로드된 파일을 지정 폴더로 이동
    # ... 파일 이동 로직 ...
    
    driver.quit()
    return "Success"

if __name__ == "__main__":
    lyrics = sys.argv[1]
    style = sys.argv[2]
    output_path = sys.argv[3]
    
    result = create_suno_song(lyrics, style, output_path)
    print(result)
```

**n8n Execute Command 설정**:
```json
{
  "command": "python",
  "arguments": [
    "C:\\automation\\suno_automation.py",
    "{{$node[\"Set Variables\"].json[\"lyrics\"]}}",
    "{{$node[\"Set Variables\"].json[\"style\"]}}",
    "{{$node[\"Trigger\"].json[\"targetFolder\"]}}"
  ]
}
```

---

### 💾 Node 9: Move MP3 to Target Folder
**Type**: Execute Command

**Purpose**: 다운로드된 MP3를 지정 폴더로 이동

**Configuration** (Windows):
```json
{
  "command": "move",
  "arguments": [
    "%USERPROFILE%\\Downloads\\suno_song_*.mp3",
    "{{$node[\"Trigger\"].json[\"targetFolder\"]}}\\kdh_ep{{$node[\"Set Variables\"].json[\"episodeNumber\"]}}_song.mp3"
  ]
}
```

---

### 🌐 Node 10: Chrome Browser Automation - Tistory 로그인
**Type**: Execute Command (Puppeteer Script)

**Purpose**: Chrome에서 Tistory 로그인

```javascript
// tistory_login.js
const puppeteer = require('puppeteer');

async function loginToTistory() {
  // 1. Chrome 열기 - 김희우 프로파일
  const browser = await puppeteer.launch({
    headless: false,
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    userDataDir: 'C:\\Users\\[사용자명]\\AppData\\Local\\Google\\Chrome\\User Data',
    args: ['--profile-directory=Profile 1'] // 김희우 프로파일
  });
  
  const page = await browser.newPage();
  
  // 2. Tistory 접속
  await page.goto('https://www.tistory.com');
  await page.waitForTimeout(2000);
  
  // 3. 카카오 로그인 클릭
  await page.click('a[href*="kakao"]');
  await page.waitForTimeout(2000);
  
  // 4. 계정 선택 (heewoo.kim@gmail.com)
  await page.click('button:has-text("heewoo.kim@gmail.com")');
  await page.waitForTimeout(3000);
  
  // 5. 블로그 선택
  await page.goto('https://[블로그주소].tistory.com');
  await page.waitForTimeout(2000);
  
  return { browser, page };
}

module.exports = { loginToTistory };
```

---

### ✍️ Node 11: Tistory 글쓰기 자동화
**Type**: Execute Command (Puppeteer Script 계속)

```javascript
// tistory_post.js (계속)
async function publishPost(browser, page, htmlContent, title, category) {
  // 1. 글쓰기 버튼 클릭
  await page.click('a[href*="/manage/newpost"]');
  await page.waitForTimeout(3000);
  
  // 2. HTML 모드 선택
  await page.click('button:has-text("html")');
  await page.click('button:has-text("확인")');
  await page.waitForTimeout(1000);
  
  // 3. HTML 내용 붙여넣기
  await page.evaluate((html) => {
    const editor = document.querySelector('#editor-content');
    if (editor) {
      editor.innerHTML = html;
    }
  }, htmlContent);
  
  // 4. 제목 입력
  await page.type('input[placeholder*="제목"]', title);
  await page.waitForTimeout(500);
  
  // 5. 카테고리 선택
  await page.click('select[name="category"]');
  await page.select('select[name="category"]', category);
  await page.waitForTimeout(500);
  
  // 6. 임시저장
  await page.click('button:has-text("임시저장")');
  await page.waitForTimeout(2000);
  
  // 7. 완료 확인
  await page.click('button:has-text("완료")');
  await page.waitForTimeout(1000);
  
  // 8. 대표 이미지 (선택사항)
  // ... 이미지 업로드 로직 ...
  
  // 9. 공개 발행
  await page.click('button:has-text("공개")');
  await page.waitForTimeout(2000);
  
  await browser.close();
  
  return "Published successfully!";
}
```

**n8n 통합**:
```json
{
  "command": "node",
  "arguments": [
    "C:\\automation\\tistory_automation.js",
    "{{$node[\"Save HTML\"].json[\"filePath\"]}}",
    "케데헌 Episode {{$node[\"Set Variables\"].json[\"episodeNumber\"]}}",
    "케데헌 시리즈"
  ]
}
```

---

### 📧 Node 12: Send Notification
**Type**: Send Email / Slack / Discord

**Purpose**: 완료 알림 발송

**Configuration** (Email):
```json
{
  "to": "heewoo.kim@gmail.com",
  "subject": "✅ 케데헌 Episode {{$node[\"Set Variables\"].json[\"episodeNumber\"]}} 발행 완료",
  "body": "에피소드가 성공적으로 발행되었습니다!\n\n- 제목: 케데헌 Episode {{$node[\"Set Variables\"].json[\"episodeNumber\"]}}\n- HTML 저장: {{$node[\"Save HTML\"].json[\"filePath\"]}}\n- MP3 저장: {{$node[\"Trigger\"].json[\"targetFolder\"]}}\\kdh_ep{{$node[\"Set Variables\"].json[\"episodeNumber\"]}}_song.mp3\n- 발행 시간: {{$now}}"
}
```

---

## 🎯 전체 워크플로우 다이어그램

```
[Manual Trigger]
       ↓
[Claude API - HTML 생성]
       ↓
[Save HTML to Folder]
       ↓
[GPT - 동요 주제 생성]
       ↓
[GPT - 가사 작성]
       ↓
[GPT - 스타일 작성]
       ↓
[Set Variables]
       ↓
[SUNO - 동요 생성]
       ↓
[Move MP3 to Folder]
       ↓
[Puppeteer - Tistory 로그인]
       ↓
[Puppeteer - 글 발행]
       ↓
[Send Notification Email]
```

---

## 🔑 필요한 API Keys & 인증

### 1. Anthropic API Key
- 발급: https://console.anthropic.com
- n8n에서 설정: Credentials → HTTP Header Auth
  - Name: `x-api-key`
  - Value: `sk-ant-...`

### 2. OpenAI API Key
- 발급: https://platform.openai.com
- n8n에서 설정: Credentials → OpenAI

### 3. SUNO 인증
- 로그인 세션 쿠키 저장 또는
- 비공식 API 사용 (유료)

### 4. Tistory 인증
- Chrome Profile 활용 (세션 유지)
- 또는 Tistory Open API 사용

---

## 📦 필요한 소프트웨어 & 라이브러리

### Windows 환경
1. **n8n 설치**
   ```bash
   npm install -g n8n
   ```

2. **Node.js & npm** (최신 LTS 버전)
   - https://nodejs.org

3. **Python 3.10+** (Selenium 사용 시)
   ```bash
   pip install selenium webdriver-manager
   ```

4. **Puppeteer** (Browser Automation)
   ```bash
   npm install puppeteer
   ```

5. **Chrome WebDriver**
   ```bash
   npm install chromedriver
   ```

---

## 🚀 n8n 워크플로우 실행 방법

### 1단계: n8n 시작
```bash
n8n start
```
브라우저에서 http://localhost:5678 접속

### 2단계: 워크플로우 Import
1. n8n 대시보드에서 "Import from File" 클릭
2. `kdh_automation_workflow.json` 파일 선택
3. 모든 노드 확인 및 설정

### 3단계: Credentials 설정
- Anthropic API Key
- OpenAI API Key
- Email SMTP 설정

### 4단계: 테스트 실행
- Manual Trigger 노드에서 "Execute Node" 클릭
- 각 노드별로 실행 확인
- 에러 발생 시 로그 확인

### 5단계: 스케줄링 (선택)
- Trigger 노드를 Schedule Trigger로 변경
- 매주 수요일 오전 10시 등으로 설정

---

## ⚠️ 주의사항 & 팁

### 1. SUNO 자동화의 어려움
- SUNO는 공식 API가 없어 Browser Automation 필요
- Cloudflare 보호로 인해 자동화가 차단될 수 있음
- 대안: SUNO 대신 다른 음악 생성 AI 사용 (Mubert, AIVA 등)

### 2. Tistory 자동화
- Puppeteer의 `headless: false` 모드 권장 (CAPTCHA 우회)
- Chrome Profile을 사용하면 로그인 유지 가능
- Tistory API가 있다면 REST API 사용이 더 안정적

### 3. 에러 핸들링
- 각 노드에 Error Workflow 연결
- 실패 시 재시도 로직 추가
- 로그 파일 저장

### 4. 파일 경로 (Windows)
- 백슬래시 `\` 사용 시 이스케이프 필요: `C:\\ai\\folder`
- 또는 슬래시 사용: `C:/ai/folder`

---

## 📊 성능 최적화

### 1. 병렬 처리
- Claude와 GPT 호출을 병렬로 실행 (단, 의존성 있는 경우 제외)
- SUNO 생성 중 Tistory 로그인 진행

### 2. 캐싱
- 템플릿 파일을 환경 변수로 저장
- 자주 사용하는 프롬프트를 재사용

### 3. 비용 절감
- Claude: 8K tokens = $0.024 (Sonnet)
- GPT-4: 1K tokens = $0.03
- 월 4회 발행 시: 약 $5-10

---

## 🔄 향후 개선 사항

1. **AI 이미지 생성 추가**
   - Midjourney/DALL-E로 대표 이미지 자동 생성
   - Tistory 발행 시 자동 업로드

2. **SEO 최적화**
   - 메타 태그 자동 생성
   - 키워드 자동 추출

3. **SNS 자동 공유**
   - 발행 후 Facebook, Twitter에 자동 포스팅

4. **Analytics 연동**
   - 조회수, 댓글 수 자동 수집
   - 월간 리포트 생성

---

## 📞 문의 & 지원

이 워크플로우에 대한 질문이나 개선 제안이 있으시면 언제든지 연락주세요!

- Email: heewoo.kim@gmail.com
- n8n Community: https://community.n8n.io
- Claude Forum: https://anthropic.com/community

---

**Version**: 1.0  
**Last Updated**: 2025-12-03  
**Author**: Claude AI & Kim Heewoo
