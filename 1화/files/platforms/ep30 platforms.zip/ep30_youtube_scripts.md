# EP30 — YOUTUBE SCRIPTS (LONG-FORM + SHORTS)
# AI Shopping Comparison — The Secret to Finding the Lowest Price Every Time
# Updated: 2026-04-28

---

## ▶ LONG-FORM VIDEO METADATA

**Title (A/B Test A):**
He Paid $70. His Neighbor Paid $52. Same Product. Same Week. | AI Price Comparison Guide for Seniors

**Title (A/B Test B):**
STOP Overpaying on Amazon! — Google Shopping, CamelCamelCamel & ChatGPT Shopping Guide for Seniors (2026)

**Description:**
Grandpa Bob paid $70 for a blood pressure monitor. His neighbor bought the exact same model for $52. Both ordered from Amazon. Same week.

The difference? His neighbor knew about three free tools that do the price-checking work for you — before you spend a single dollar.

In Episode 30 of AI Decoded for Seniors, Jake walks Grandpa Bob through the complete smart shopping system:

✅ Google Shopping — compare ALL stores at once, in seconds
✅ CamelCamelCamel — see a product's real price history (is that "sale" genuine?)
✅ ChatGPT — get AI product recommendations tailored to YOUR needs
✅ The AI Review Summarizer — read 500 reviews in 30 seconds
✅ 3 rules that guarantee the lowest price every time

No more buyer's remorse. No more overpaying. Starting with your very next purchase.

🕐 CHAPTERS:
0:00 — The $18 difference Grandpa Bob never needed to lose
1:15 — The 3-step smart shopping system
2:30 — Google Shopping: compare ALL stores at once
4:15 — CamelCamelCamel: is that Amazon sale actually real?
6:00 — ChatGPT: your free AI product advisor
7:30 — The AI Review Summarizer: 500 reviews in 30 seconds
8:45 — The real lowest price formula (base + shipping − discounts)
9:45 — 3 rules every senior should follow before clicking Buy Now
10:45 — "Look before you leap" — Today's Saying
11:30 — Quiz + Recap
12:00 — Jake's savings challenge to viewers

📌 Free tools:
• Google Shopping: https://shopping.google.com/
• CamelCamelCamel: https://camelcamelcamel.com/
• ChatGPT: https://chat.openai.com/

#SmartShopping #CamelCamelCamel #GoogleShopping #AIForSeniors #AmazonDeals

---

## 🎬 FULL LONG-FORM SCRIPT

---

### [INTRO — 0:00–1:15]

**[ON SCREEN: Two Amazon order confirmations side by side. Same blood pressure monitor. One: $70.00. Other: $52.00. Ordered same week.]**

**JAKE (V.O.):**
"Grandpa Bob's doctor told him to monitor his blood pressure at home.
He searched Amazon. Found a well-reviewed upper-arm monitor.
Price: $69.99.
He clicked Buy Now.

Three days later, he mentioned it to his neighbor at the mailbox.
His neighbor had bought the exact same model.
Same brand. Same Amazon listing.
Price: $51.87.

Same week. Eighteen dollars different.

Grandpa Bob had no idea."

**[CUT TO: Jake, direct to camera, upbeat]**

**JAKE:**
"That $18 isn't just $18. It's the difference between paying the real price and paying the inflated price that Amazon's algorithm decided to show you that day.

Amazon changes prices thousands of times per day — on millions of products.
Sometimes the price you see is genuine. Sometimes it's marked up.
And without the right tools, there's no way to tell the difference.

Today I'm going to give you the complete system that Grandpa Bob's neighbor uses.
Three tools. All completely free.
Starting with your very next purchase.

I'm Jake. This is AI Decoded for Seniors, Episode 30.
Let's go."

---

### [SEGMENT 1 — THE 3-STEP SMART SHOPPING SYSTEM — 1:15–2:30]

**[ON SCREEN: Simple flowchart: Step 1 → Step 2 → Step 3]**

**JAKE:**
"Here's the complete system — three steps, in order, every time you shop online.

Step One: Use Google Shopping to see all stores at once.
Step Two: Use CamelCamelCamel to verify the Amazon price is genuinely good.
Step Three: Use ChatGPT to make sure you're buying the right product for your specific needs.

Three tools. Each takes less than two minutes.
Together, they guarantee you're getting the right product at the real lowest price.

Let me walk through each one."

---

### [SEGMENT 2 — GOOGLE SHOPPING — 2:30–4:15]

**[ON SCREEN: Google Shopping live demo — screen recording]**

**JAKE:**
"Step One: Google Shopping.

Most people search Amazon directly — which means they only see Amazon's prices.
But the exact same product is often available at Walmart, Target, Best Buy, Chewy, or dozens of specialty retailers — sometimes significantly cheaper.

Google Shopping checks all of them at once.

Here's exactly how:

Step One: Go to Google. Type the exact product name — be specific.
For example: 'Omron BP7350 upper arm blood pressure monitor.'

Step Two: Click the 'Shopping' tab at the top of the results — it's next to 'All,' 'News,' 'Images.'

Step Three: On the left sidebar — or at the top of results — find the sort dropdown.
Select 'Price: Low to High.'

You now see the same product across every major US retailer — with prices, shipping costs, and availability — all in one view.

Step Four: Before you click anything — look at the TOTAL price.
Base price plus shipping.
A $60 item with $12 shipping is $72.
A $65 item with free shipping is $65.
The $65 is the better deal.

[PAUSE]

This single step — using Google Shopping instead of going directly to Amazon — saves the average online shopper between 8 and 15 percent on most purchases, according to consumer research.

Grandpa Bob's blood pressure monitor?
Google Shopping found it at a medical supply retailer for $54.99 with free shipping.
Same exact model.
His Amazon order was $69.99.
Fifteen dollars saved in two minutes."

---

### [SEGMENT 3 — CAMELCAMELCAMEL: THE PRICE TRUTH DETECTOR — 4:15–6:00]

**[ON SCREEN: CamelCamelCamel website demo]**

**JAKE:**
"Step Two: CamelCamelCamel. And this one is truly eye-opening.

CamelCamelCamel tracks the price history of every product on Amazon — going back years.
It shows you a complete graph: the highest price, the lowest price, and the average price.

So when you see 'Was $89.99 — Now $59.99 — 33% off!'
CamelCamelCamel tells you whether $59.99 is actually a deal — or just the normal everyday price with a fake 'was' number attached.

Here's how to use it:

Step One: Go to camelcamelcamel.com on your phone or computer.

Step Two: Copy the Amazon URL — the web address — of the product you're looking at.
Paste it into the search bar on CamelCamelCamel.
Click search.

Step Three: You see the complete price history graph.
The blue line shows all-time price.
The red dotted line shows the average.

If today's price is below the average — it's a real deal.
If today's price is AT the average or above — wait. The price will likely drop again soon.

[REAL EXAMPLE — on screen]

I searched for a popular blood pressure monitor on CamelCamelCamel.
The 'sale' price that day: $64.99.
Historical lowest price: $44.99.
All-time average price: $58.00.

The $64.99 'sale' was actually above average. Not a deal at all.
Two weeks later, the price dropped to $49.99.
Buying on that 'sale' day would have cost $15 more than waiting.

[PAUSE]

You can also set a price drop alert on CamelCamelCamel.
Enter your email. Choose your target price.
When the product drops to that price — you get an email automatically.
You don't have to check constantly. The site watches for you."

---

### [SEGMENT 4 — CHATGPT: YOUR FREE PRODUCT ADVISOR — 6:00–7:30]

**[ON SCREEN: ChatGPT conversation demo]**

**JAKE:**
"Step Three: ChatGPT. And this is where AI shopping gets genuinely powerful.

Google Shopping and CamelCamelCamel tell you about PRICE.
ChatGPT tells you about the right PRODUCT.

Because here's the problem most seniors run into: they find the cheapest option — and it turns out to be wrong for their specific situation.

A blood pressure monitor that's cheap but has tiny buttons and a small screen.
An arthritis brace that's highly rated — but not for people with severe joint involvement.
A hearing device that's inexpensive but requires a smartphone app they can't use.

ChatGPT solves this with specific, personalized recommendations.

Here's the prompt Grandpa Bob used:
'Recommend the best upper-arm blood pressure monitor under $70 for a 72-year-old man with mild arthritis. I need large buttons, a big easy-to-read display, and simple one-touch operation. Reliability and accuracy are most important.'

ChatGPT responded with:
Three specific models. For each: key features, pros, cons, and the specific reason it fits Grandpa Bob's stated needs.
It also noted which features mattered most for arthritis management and why some popular models would be difficult for him to operate.

Then Grandpa Bob took those three model names and checked their prices on Google Shopping and their price histories on CamelCamelCamel.

That combination — the right product at the right time at the right price — is the complete system."

---

### [SEGMENT 5 — THE AI REVIEW SUMMARIZER — 7:30–8:45]

**[ON SCREEN: Amazon product page with review summary feature]**

**JAKE:**
"Before I close out the tools section — let me show you one more feature that Amazon itself has added: the AI review summarizer.

On most popular Amazon products, you'll now see a section near the top of the reviews that says 'Customers say' — with a short paragraph summarizing what hundreds of customers love and what they complain about.

This AI-generated summary replaces reading hundreds of individual reviews.
It tells you the consensus: what works, what doesn't, what's frequently mentioned as a problem.

For Grandpa Bob's blood pressure monitor — the AI summary said:
'Customers appreciate the large display and simple one-touch operation. Several customers report the cuff fits comfortably even for larger arms. Common complaints include the storage case being flimsy and occasional app connectivity issues.'

Two minutes of reading. The equivalent of hundreds of reviews.

And for any product where Amazon hasn't yet added this feature?
Copy the product name and the three most common uses into ChatGPT and ask:
'Based on common customer feedback, what are the main pros and cons of [product]?'
ChatGPT will synthesize its training data to give you a similar summary."

---

### [SEGMENT 6 — THE REAL LOWEST PRICE FORMULA — 8:45–9:45]

**[ON SCREEN: Simple math formula visual]**

**JAKE:**
"Here's the formula every senior needs to know before clicking Buy Now.

Real lowest price = Base price + Shipping cost − Payment discounts

This sounds obvious. But most people skip steps two and three.

On shipping: free shipping is not always free. Some sites offer free shipping only above a minimum order. Check whether you actually qualify before assuming.

Amazon Prime members get free two-day shipping on most items. If you order online more than a few times per month, Prime typically pays for itself.

On payment discounts: many retailers offer additional percentage discounts for paying with their store credit card, PayPal, or specific payment methods.
Amazon Visa card: 5% back on Amazon purchases.
Target RedCard: 5% off everything at Target.
These stack on top of the sale price.

The full formula for Grandpa Bob's monitor:
Best found price: $54.99
Shipping: Free (qualified for the retailer's free shipping threshold)
Payment discount: 3% cashback card = $1.65 back
Real price paid: $53.34

Versus the original Amazon order: $69.99.
Total saved: $16.65 on one purchase.
With this system applied to every purchase: the savings compound significantly over a year."

---

### [SEGMENT 7 — 3 RULES BEFORE CLICKING BUY NOW — 9:45–10:45]

**[ON SCREEN: Bold numbered list]**

**JAKE:**
"Three rules. Every purchase. Starting today.

Rule One: Never buy from the first site you see.
Check Google Shopping before buying anywhere. Takes 90 seconds.
This rule alone saves 10 to 15 percent on most purchases.

Rule Two: For any purchase over $30 on Amazon — check CamelCamelCamel first.
The 'sale' price may not be a sale at all.
A two-minute price history check tells you the truth.

Rule Three: For anything you're unsure about — ask ChatGPT first.
Describe your specific needs. Get specific recommendations.
Then price-check those specific models.
Buying the right product at full price beats buying the wrong product at a discount."

---

### [OUTRO — SAYING + RECAP — 10:45–12:00]

**JAKE:**
"Today's American Saying: 'Look before you leap.'

Before you click Buy Now — look at Google Shopping.
Before you trust an Amazon sale — look at CamelCamelCamel.
Before you choose a product — look at what ChatGPT recommends for your specific needs.

Three looks. Every leap. You'll never overpay again.

Quick recap:
One: Google Shopping — type product name, click Shopping tab, sort by lowest price, check total with shipping.
Two: CamelCamelCamel — paste Amazon URL, see price history, set drop alerts for target price.
Three: ChatGPT — describe your specific needs, get personalized product recommendations.
Four: Real lowest price = base price + shipping minus payment discounts.
Five: Three rules — check all stores, verify Amazon sales, ask ChatGPT for the right product.

Here's my savings challenge to you:
Try this system on your next online purchase — whatever it is.
Come back and tell me in the comments: How much did you save?

I want to see the numbers. I read every comment.

I'm Jake. This has been AI Decoded for Seniors, Episode 30.
See you next episode."

**[END SCREEN: Subscribe + EP31 preview + full playlist card]**

---

## 📋 PRODUCTION CHECKLIST

- [ ] Recreate the two Amazon receipts intro visual (most critical hook — recreate with stock design, not real receipts)
- [ ] Screen record Google Shopping live — blood pressure monitor search, sort by price, compare stores
- [ ] Screen record CamelCamelCamel — paste Amazon URL, show price history graph, set alert
- [ ] Screen record ChatGPT product recommendation prompt + response
- [ ] Screen record Amazon AI review summarizer feature
- [ ] Add the "Real Lowest Price Formula" as an animated infographic
- [ ] Add all chapter timestamps to description
- [ ] Closed captions (mandatory — seniors are primary audience)
- [ ] Thumbnail: Two price tags — $70 crossed out, $52 circled in gold — "AI Found the REAL Price"
- [ ] End screen: 20-second countdown with subscribe + full playlist (EP26–30 series card)
- [ ] Add series milestone note: "That's EP30 — thank you for watching the whole series!"

---

*Disclaimer: Prices, discounts, and availability are subject to change. This content reflects shopping strategies as of 2026 and is for educational purposes. Always verify current prices before purchasing.*
*Sources: Google Shopping Official Documentation; CamelCamelCamel.com; OpenAI ChatGPT*

===================================================================

# EP30 — YOUTUBE SHORTS / TIKTOK / REELS SCRIPTS

---

## SHORT #1 — "The CamelCamelCamel Reveal" (Highest engagement — exposes the scam)

**Hook text (0–2 sec):** "That Amazon 'sale' price? It might not be a sale at all. Here's how to check in 10 seconds. 🐪"

[0:00–0:04] JAKE (fast, urgent):
"Amazon changes its prices thousands of times every day. That 'Was $89 — Now $59, 33% off!' label? It might be completely fabricated."

[0:04–0:18] JAKE + TEXT:
"CamelCamelCamel.com — free. Paste any Amazon product URL. See the complete price history going back years."

TEXT ON SCREEN:
"'Sale price' today: $64.99"
"Historical AVERAGE: $58.00"
"Historical LOW: $44.99"
"→ $64.99 is NOT a deal. It's above average."

[0:18–0:35] JAKE:
"That 'sale' price was actually more expensive than normal. I waited 2 weeks. Price dropped to $49.99. Saved $15 on the exact same product by not clicking 'Buy Now' on day one."

[0:35–0:50] JAKE:
"You can also set a Price Drop Alert. Enter your email. Choose your target price. CamelCamelCamel emails you the moment it drops. You never have to check manually again."

[0:50–0:58] CTA: "camelcamelcamel.com — free. Check your next Amazon purchase before you buy. Follow for more."

**Caption:** That Amazon "sale" price might not be a sale at all. CamelCamelCamel shows you the real price history — free. Here's the blood pressure monitor I almost overpaid for by $15. #CamelCamelCamel #AmazonDeals #SmartShopping #AIForSeniors #PriceTracker #SaveMoney

---

## SHORT #2 — "The 90-Second Price Check" (Practical, fast)

**Hook:** "Never check just one store before buying online. Here's the 90-second rule. ⏱️"

[0:00–0:05] JAKE:
"Most people search Amazon, find a product, and click Buy Now. That's the most expensive way to shop online."

[0:05–0:20] JAKE:
"Google Shopping. Free. Search the exact product name on Google. Click the Shopping tab. Sort by Price: Low to High.
You now see that same product across Amazon, Walmart, Target, and dozens of other stores — all at once."

[0:20–0:38] TEXT ON SCREEN (fast flash):
"Blood pressure monitor — Amazon: $69.99"
"Same item — Medical supply store: $54.99"
"Same item — Walmart.com: $58.00"
"→ Google Shopping found it $15 cheaper. 90 seconds."

[0:38–0:52] JAKE:
"But — always calculate TOTAL price. Base price plus shipping.
$54.99 with free shipping beats $52.99 with $8 shipping.
Always do the full math before clicking."

[0:52–0:58] CTA: "This one habit saves 10–15% on every online purchase. Follow for the full smart shopping system."

**Caption:** Most people only check Amazon. Google Shopping shows you that same product at every major store — at once. I found it $15 cheaper in 90 seconds. #GoogleShopping #SmartShopping #OnlineShopping #SaveMoney #AIForSeniors #ShoppingTips

---

## SHORT #3 — "ChatGPT Product Advisor" (Aspirational — AI as personal shopper)

**Hook:** "I asked ChatGPT to recommend a blood pressure monitor for a 72-year-old with arthritis. It knew exactly what to look for."

[0:00–0:06] JAKE:
"Most people buy the cheapest option they find. Then return it because it doesn't work for their specific situation. ChatGPT prevents this."

[0:06–0:22] TEXT ON SCREEN (ChatGPT prompt):
"'Recommend the best upper-arm blood pressure monitor under $70 for a 72-year-old with mild arthritis. Large buttons. Big display. One-touch operation. Accuracy most important.'"

[0:22–0:40] JAKE:
"ChatGPT gave me 3 specific models. For each: the exact features that match the request, the pros, the cons, and WHY it's right for arthritis management.
It even flagged which popular options would be difficult to operate with arthritic hands."

[0:40–0:52] JAKE:
"Then I took those 3 model names. Checked prices on Google Shopping. Verified the Amazon price history on CamelCamelCamel. Bought the right product at the real lowest price."

[0:52–0:58] CTA: "Right product + lowest real price = smart shopping. Full system guide in bio. Follow for more."

**Caption:** ChatGPT recommended the exact right blood pressure monitor for a 72-year-old with arthritis — specific models, specific reasons. Then I price-checked with CamelCamelCamel. Complete system in bio. #ChatGPT #SmartShopping #AIForSeniors #AmazonTips #ShoppingHacks
