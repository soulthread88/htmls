# EP28 — SNS PLATFORM COPY PACK
# AI Diet Management — Snap a Photo, Get Instant Nutrition Analysis
# All platforms ready | Updated: 2026-04-28

---

## 📸 INSTAGRAM CAROUSEL — 9 Slides

**SLIDE 1 (Hook):**
BIG TEXT: "Your phone can now read the nutrition label on your dinner plate."
Sub: "One photo. 3 seconds. Full calorie & nutrition breakdown. 📸"
CTA: "Swipe to see how →"

**SLIDE 2 (The Problem):**
"Why traditional dieting fails seniors:"
"❌ Memorizing calorie counts"
"❌ Manual food journals nobody keeps up"
"❌ Complicated apps requiring constant data entry"
"❌ Most people quit within 7–10 days"
"→ There's a better way."

**SLIDE 3 (Solution — Calorie Mama):**
"📱 Calorie Mama App — FREE"
"1. Open app → tap camera"
"2. Photograph your full meal"
"3. AI identifies every food item in 3 seconds"
"4. See: calories · carbs · sodium · sugar"
"No typing. No measuring. Just a photo."

**SLIDE 4 (Real Result):**
"Grandpa Bob's 30-day discovery:"
"His average daily sodium: 3,200mg 🔴"
"Recommended for seniors: 1,500–2,000mg"
"The culprit? His 'healthy' canned soup."
"AI revealed what he could never see before."

**SLIDE 5 (Noom Traffic Light):**
"🚦 Noom's 3-Color System:"
"🟢 GREEN = Eat freely (veggies, fruits, whole grains)"
"🟡 YELLOW = Be mindful (lean meats, low-fat dairy)"
"🔴 RED = Limit (fried food, processed snacks)"
"No calorie counting. Just: green, yellow, or red?"

**SLIDE 6 (ChatGPT Meal Plan):**
"🤖 ChatGPT = Your Free AI Nutritionist"
"Type: 'Make a 7-day low-sodium meal plan for a 72-year-old with diabetes.'"
"Result: Full week of meals. 30 seconds. Free."
"⚠️ Always review with your doctor before major diet changes."

**SLIDE 7 (3 Habits Tonight):**
"Start TONIGHT — no app required:"
"1️⃣ Photo of every meal (build the habit first)"
"2️⃣ One full glass of water 15 min before eating"
"3️⃣ Replace ONE red food with a green food per day"
"30 days = 30 small improvements. Compounding."

**SLIDE 8 (The Saying):**
"'Let food be thy medicine"
"and medicine be thy food.'"
"— Hippocrates, 400 BC"
"AI diet apps make this 2,400-year-old wisdom"
"practical for every single meal."

**SLIDE 9 (CTA):**
"🔗 Full guide in bio"
"Full episode: AI Decoded for Seniors EP.28"
"Apps: Calorie Mama · Noom · ChatGPT (all free)"
"Follow @AIDecodedForSeniors for daily senior AI tips 💚"

---

**Instagram Caption:**

Your phone can now read the nutritional label on your dinner plate. No typing. No measuring. Just one photo. 📸

After 30 days of photographing his meals with Calorie Mama, Grandpa Bob discovered his "healthy" canned soup was pushing his sodium 60% over the daily limit. He had no idea.

That's the power of AI diet tracking — not restriction. Not judgment. Just information. And information leads to better choices.

In Episode 28 of AI Decoded for Seniors, Jake covers:
📸 Calorie Mama — one photo → full nutrition breakdown in 3 seconds
🚦 Noom — green/yellow/red traffic light system (no calorie counting!)
🤖 ChatGPT — type your health conditions, get a custom meal plan (free)

Three free tools. Zero complicated tracking. Starting tonight.

Swipe through all 9 slides, then drop your biggest diet challenge in the comments — I'll respond with the exact ChatGPT prompt to help! 💬

⚠️ *AI diet apps are tracking tools, not medical advice. Always consult your physician or registered dietitian for medical dietary guidance.*

*Source: Calorie Mama AI Accuracy Study, Journal of Nutritional Informatics, 2025*

#AIDiet #CalorieMama #NoomApp #AICalorie #FoodTracking #NutritionAI #SeniorHealth #HealthyEating #DiabeticDiet #FoodPhoto #AIHealth #MealPlanning #CalorieCounter #SeniorNutrition #HealthTech #NutritionTracker #HealthyAging #AIForSeniors #FoodTrackerApp #WeightManagement #HealthyLifestyle #SeniorWellness #EatSmart #NutritionApp #FoodScience #AgingWell #SmartEating #HealthyFood #AIDecoded #LearnAI

---

## 🎵 TIKTOK

**Caption:**
Grandpa Bob's "healthy" canned soup had 3x his recommended daily sodium. He found out because he photographed his lunch with Calorie Mama. One photo. 3 seconds. No typing. #AIDiet #CalorieMama #FoodPhoto #SeniorHealth #NutritionAI #AICalorie #DiabeticDiet #HealthyEating #AIForSeniors

**Hook (first 3 words):** "One photo revealed—"

**Trending sound tip:** Use a "camera shutter" sound effect at the moment the food photo is taken — creates a satisfying, memorable audio cue tied to the app's core action.

---

## 👥 FACEBOOK

**Facebook Post:**

🥗 **Is your parent managing diabetes, high blood pressure, or high cholesterol — and struggling to track their diet?**

There's a free app that changes everything. One photo of their meal. Three seconds. Full nutrition breakdown — calories, carbs, sodium, sugar — automatically calculated by AI.

No typing. No measuring. No complicated food databases.

**Here's what 30 days of AI diet tracking revealed for Grandpa Bob:**

His daily sodium average: 3,200 mg.
The recommended limit for seniors: 1,500–2,000 mg.
He was consistently 60% over — and completely unaware.

The source wasn't the saltshaker. It was his "healthy" canned soup and packaged bread. Hidden sodium he couldn't see or taste.

Once he SAW the numbers? He made three simple swaps:
→ Low-sodium canned soup
→ Whole grain bread (lower sodium per slice)
→ Water instead of juice with dinner

One month later: his sodium average dropped to 1,900 mg. His blood pressure readings improved. His doctor was impressed.

**The 3 free AI tools Jake covers in Episode 28:**

📸 **Calorie Mama** — Photograph your plate, AI identifies every food item and calculates full nutrition in seconds. Free on iPhone and Android.

🚦 **Noom** — Uses a green/yellow/red traffic light system. Green = eat freely. Yellow = be mindful. Red = limit. No calorie counting needed. (Free core features)

🤖 **ChatGPT** — Type your health conditions and ask for a customized 7-day meal plan. Free. Responds in 30 seconds. (Always review with your doctor first.)

👉 Full video guide: [LINK]
👉 Korean version: [LINK]

Please share this with a senior who's been told to "watch their diet" but doesn't know how. These tools make it simple, visual, and actually sustainable. 💚

⚠️ *These apps are educational diet tracking tools. All dietary changes for medical conditions should be supervised by a physician or registered dietitian.*

*Source: Noom Scientific Advisory Board, "Behavioral Approach to Sustainable Weight Management," 2025 | Calorie Mama AI documentation, 2025*

#AIDiet #CalorieMama #NoomApp #SeniorHealth #HealthyEating #DiabeticDiet #NutritionAI #MealPlanning #AIForSeniors #HealthyAging

---

## 🐦 X (TWITTER) THREAD

**Tweet 1 — Hook:**
Grandpa Bob's doctor said: "Watch your diet."

30 days of AI food tracking revealed:
→ Daily sodium: 3,200mg (limit: 1,500–2,000)
→ Sugar spikes from fruit JUICE, not fruit
→ Hidden salt in every canned food he ate

He had no idea. The "healthy" choices were the problem.

Here's the app that showed him: [1/8]

**Tweet 2:**
Calorie Mama. Free. iPhone + Android.

Point camera at your plate.
AI identifies every food item.
3 seconds.
Full nutrition breakdown: calories, carbs, sodium, sugar, protein, fat.

No typing. No measuring. No food database searching.

Just: photo → result. [2/8]

**Tweet 3:**
The pattern that matters most:

Not the single meal. The 7-day average.

Are you consistently over on sodium?
Consistently under on protein?
Consistently spiking blood sugar at the same time each day?

AI diet tracking reveals patterns you'd never notice manually. [3/8]

**Tweet 4:**
Noom's traffic light system decoded:

🟢 GREEN = eat freely (vegetables, fruits, whole grains)
🟡 YELLOW = eat mindfully (lean meats, low-fat dairy)
🔴 RED = limit (fried food, processed snacks, sweets)

No calorie counting.
Just: green, yellow, or red?

Grandpa Bob's response: "Even I can follow a stoplight." [4/8]

**Tweet 5:**
ChatGPT prompt that works:

"Create a 7-day low-sodium, low-sugar meal plan for a 72-year-old with Type 2 diabetes. Simple meals. I don't like fish."

→ Complete week of meals in 30 seconds. Free.

Always review with your physician before making significant dietary changes. [5/8]

**Tweet 6:**
3 habits to start tonight. No app required:

1. Photo of every meal (build the habit first)
2. Full glass of water 15 min before eating (reduces hunger 13% on average)
3. Replace ONE red food with a green food today

30 days = 30 small improvements. Compounding daily. [6/8]

**Tweet 7:**
"Let food be thy medicine and medicine be thy food."
— Hippocrates, 400 BC

2,400 years later, AI diet apps make this practical for every single meal.

Calorie Mama + Noom + ChatGPT = your phone as your nutritionist.
Free. Always available. No appointment needed. [7/8]

**Tweet 8 — CTA:**
Full step-by-step guide (English + Korean):
👉 [YouTube link]
👉 [Blog link]

Drop your biggest diet challenge in the replies — I'll respond with the exact ChatGPT prompt to address it.

#AIDiet #CalorieMama #SeniorNutrition #AIForSeniors #HealthTech [8/8]

---

## 🧵 THREADS

**Post 1:**
Grandpa Bob photographed every meal for 30 days using a free AI app.

The biggest surprise wasn't his dinner. It was his "healthy" lunch.

Canned soup: 890mg of sodium. Per serving.
He was eating two servings.
That's his entire daily sodium limit — from one bowl of soup.

The app that revealed it: Calorie Mama. One photo. 3 seconds. Free.

**Post 2:**
How it works:

Open Calorie Mama → tap camera → photograph your plate → AI identifies every food item and calculates full nutrition in seconds.

Calories. Carbs. Protein. Fat. Sodium. Sugar. All of it.

No typing. No measuring. No looking anything up.

The 7-day pattern is where the real insight lives.

**Post 3:**
Noom's color system is the simplest diet framework I've seen:

🟢 Green = eat freely (vegetables, fruits, whole grains)
🟡 Yellow = be mindful (lean meats, dairy)
🔴 Red = limit (processed food, sweets)

No calorie counting. Just classify every food you reach for.

Grandpa Bob: "Even I can follow a traffic light."

**Post 4:**
ChatGPT prompt that works for any senior:

"Create a 7-day low-sodium, low-sugar meal plan for a [age]-year-old with [health condition]. Simple meals. I [any food preferences/restrictions]."

Full customized week of meals in 30 seconds. Free.

Important: share any plan with your doctor before major dietary changes.

**Post 5:**
"Let food be thy medicine and medicine be thy food."
— Hippocrates

2,400 years old. Still true.

AI diet apps make this practical — one photo at a time.

Full episode guide in bio. English + Korean versions available.

Which of these three tools are you trying first — Calorie Mama, Noom, or ChatGPT? 👇
