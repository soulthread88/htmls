# EP28 — YOUTUBE LONG-FORM SCRIPT
# Title: "Take ONE Photo of Your Meal — AI Tells You Everything (Calorie Mama, Noom & ChatGPT for Seniors)"
# Target Length: 10–12 minutes | Format: Hook + Demo + Tutorial
# Channel: AI Decoded for Seniors
# Updated: 2026-04-28

---

## ▶ VIDEO METADATA

**Primary Title (A/B Test A):**
I Photographed Every Meal for 30 Days — Here's What AI Revealed About My Diet (Seniors Guide)

**Primary Title (A/B Test B):**
Stop Counting Calories by Hand! This Free AI App Does It From ONE Photo | Calorie Mama & Noom for Seniors

**Description:**
Managing your diet shouldn't mean filling out complicated food journals or memorizing calorie counts. With AI diet apps, you just snap a photo of your meal — and the app instantly calculates calories, carbs, sodium, sugar, and more.

In this episode of AI Decoded for Seniors, Jake walks Grandpa Bob through three powerful free AI tools:

✅ Calorie Mama — take a photo, AI identifies every food item instantly
✅ Noom — green/yellow/red traffic light system for smart food choices
✅ ChatGPT — get a personalized meal plan for diabetes, high blood pressure, or cholesterol

No gym required. No complicated charts. Just your phone and your plate.

🕐 CHAPTERS:
0:00 — Grandpa Bob's doctor gave him a diet warning
1:15 — Why traditional calorie counting fails seniors
2:30 — Calorie Mama: how photo recognition works
4:00 — Step-by-step: your first photo nutrition scan
5:30 — Noom: the traffic light food system
7:00 — ChatGPT: your free AI nutritionist
8:30 — What the data revealed after 30 days
9:45 — 3 habits starting tonight
11:00 — Today's saying + recap
11:45 — Jake's challenge to viewers

📌 Free tools in this video:
• Calorie Mama: https://caloriemama.ai/
• Noom: https://www.noom.com/
• ChatGPT: https://chat.openai.com/

⚠️ Disclaimer: AI diet apps are for educational and tracking purposes only. Always consult your physician or registered dietitian for medical dietary guidance.

#AIDiet #CalorieMama #NoomApp #ChatGPT #SeniorNutrition #AIForSeniors #FoodTracking

---

## 🎬 FULL SCRIPT

---

### [INTRO — 0:00–1:15]

**[ON SCREEN: Doctor's office. Clipboard. The words "Watch Your Diet" written in bold.]**

**JAKE (V.O.):**
"Grandpa Bob's doctor gave him the news after his last checkup.
Blood sugar: too high.
Sodium: way too high.
Cholesterol: needs work.

His doctor said three words that most seniors dread:
'Watch. Your. Diet.'

But nobody told Grandpa Bob HOW."

**[CUT TO: Jake, relaxed and warm, direct to camera]**

**JAKE:**
"Hey everyone — welcome back to AI Decoded for Seniors. I'm Jake.

Here's the truth about diet tracking: the old way is exhausting.
Writing down every food. Looking up calorie counts. Measuring portions.
Most people — especially seniors — give up within a week. Not because they don't care. Because the system is too complicated.

But AI has completely changed this.

Today I'm going to show you three apps that make healthy eating as easy as taking a photo.
No typing. No measuring. No complicated food databases.
Just your phone, your plate, and AI.

Grandpa Bob — are you ready?"

**GRANDPA BOB (V.O.):**
"My doctor said watch my diet. You're telling me my phone can do that FOR me?"

**JAKE:**
"That's exactly what I'm telling you. Let's go."

---

### [SEGMENT 1 — WHY TRADITIONAL DIET TRACKING FAILS — 1:15–2:30]

**[ON SCREEN: Montage of complicated food diaries, calorie charts, overwhelming apps]**

**JAKE:**
"First — let's understand why traditional calorie counting is so hard.

Problem one: It requires memorization.
How many calories in a bowl of oatmeal? A chicken breast? Half a cup of rice?
Most people don't know — and looking it up every single meal is exhausting.

Problem two: It misses hidden ingredients.
That soup Grandpa Bob had for lunch? He doesn't know how much sodium is in it.
The salad dressing? Unknown sugar content. The bread at dinner? Portion size is a guess.

Problem three: It's time-consuming.
Studies show the average person gives up manual food tracking within 7 to 10 days.

AI photo recognition fixes all three of these problems simultaneously.
You take a photo. The AI identifies every visible food item. It calculates the full nutritional breakdown automatically.
No memorization. No hidden ingredients missed. Seconds, not minutes."

---

### [SEGMENT 2 — CALORIE MAMA: PHOTO NUTRITION SCANNING — 2:30–5:30]

**[ON SCREEN: Calorie Mama app live demo — smartphone screen recording]**

**JAKE:**
"Let's start with Calorie Mama — the gold standard for AI photo food recognition.

Here's how it works:

Step One: Download Calorie Mama from the App Store or Google Play. It's free.

Step Two: Open the app. Tap the camera icon at the bottom.

Step Three: Point your camera at your plate — the entire meal.
Hold it steady for two seconds.
Tap the shutter button.

Step Four: Watch the magic.
Within about three seconds, AI scans the photo and identifies every food item it can see.
It draws boxes around each item and labels them.
Bowl of oatmeal. Banana. Glass of orange juice.

Step Five: Confirm or adjust.
Tap each item to confirm the portion size.
If anything was misidentified — tap to correct it.

Step Six: See your full nutritional breakdown.
Calories. Carbohydrates. Protein. Fat. Sodium. Sugar. Fiber.
All calculated. All displayed. In seconds.

[PAUSE]

Grandpa Bob asked me: 'But what if the AI gets it wrong?'

Great question. The accuracy is impressive — around 80 to 90 percent for common foods according to independent testing. Where it can struggle: mixed dishes like casseroles, or foods with sauces that cover the ingredients.

For those cases: tap the manual entry option and type in the dish name. The database has over 6 million foods.

The real power isn't perfect accuracy on every single meal.
The real power is the PATTERN it reveals over 7 days, 14 days, 30 days.
Are you consistently eating too much sodium? Too many simple carbs? Not enough protein?
AI shows you the trend. And that's where the real health insight lives."

---

### [SEGMENT 3 — NOOM: THE TRAFFIC LIGHT SYSTEM — 5:30–7:00]

**[ON SCREEN: Noom app interface — food color categories]**

**JAKE:**
"Now let's talk about Noom — and the reason millions of Americans love it:
the traffic light system.

Noom classifies every food into one of three color categories.

GREEN foods: Low calorie density. High volume. Eat as much as you want.
Examples: vegetables, fruits, whole grains, lean proteins.
These are your Grandpa-Bob-approved unlimited foods.

YELLOW foods: Moderate calorie density. Eat mindfully — smaller portions.
Examples: lean meats, low-fat dairy, beans, legumes.
These are the middle ground — not bad, just be aware of how much.

RED foods: High calorie density. Limit these.
Examples: processed foods, fried foods, full-fat dairy, alcohol, sweets.
These aren't forbidden — Noom is not about restriction, it's about awareness.

Grandpa Bob looked at this and said — 'Even I can understand a stoplight.'

That's exactly the point. Noom's color system removes all the math.
You don't need to count calories.
You don't need to read labels.
You just ask: is this food green, yellow, or red?
And you eat accordingly.

For seniors managing diabetes, high blood pressure, or high cholesterol —
building a diet around mostly green foods with mindful yellows is one of the most effective sustainable approaches in nutritional research.

[PAUSE]

One honest note: Noom's full program has a paid subscription component.
But the core food tracking and color coding is free. That's all most seniors need to start."

---

### [SEGMENT 4 — CHATGPT: YOUR FREE AI NUTRITIONIST — 7:00–8:30]

**[ON SCREEN: ChatGPT conversation on laptop/phone]**

**JAKE:**
"Now for the tool that surprised Grandpa Bob the most: ChatGPT.

Most people think of ChatGPT as a chatbot that answers questions.
But for diet management, it's essentially a free nutritionist available 24 hours a day.

Here are three prompts Grandpa Bob actually used:

Prompt One:
'Create a 7-day low-sodium, low-sugar meal plan for a 72-year-old man with Type 2 diabetes. I can cook simple meals. I don't like fish.'

ChatGPT generated a complete week of meals — breakfast, lunch, dinner, and snacks — with estimated nutritional information for each meal. Customized. Practical. In about 30 seconds.

Prompt Two:
'I had this for lunch: [description of meal]. How can I make it healthier without giving up the things I enjoy?'

ChatGPT analyzed the meal and offered specific, practical substitutions — lower sodium seasonings, portion adjustments, vegetable additions — without stripping away all the enjoyment.

Prompt Three:
'My doctor said my A1C is 7.8. What foods should I focus on eating more of and what should I reduce?'

ChatGPT provided a clear, plain-English explanation of glycemic index, foods to prioritize, and foods to limit — and suggested bringing the summary to discuss with the doctor.

[IMPORTANT LEGAL NOTE — ON SCREEN TEXT:]
'ChatGPT is an AI tool, not a licensed physician or registered dietitian.
All dietary advice from ChatGPT should be discussed with your doctor before making significant changes to your diet.
People with serious medical conditions should always follow physician-prescribed dietary guidelines.'

That disclaimer matters. But within those boundaries — ChatGPT is an extraordinary starting point for understanding your own diet."

---

### [SEGMENT 5 — WHAT 30 DAYS OF DATA REVEALED — 8:30–9:45]

**[ON SCREEN: Sample weekly nutrition graphs — representative data, not real patient data]**

**JAKE:**
"After 30 days of using Calorie Mama, here's what Grandpa Bob's data showed.

Average daily sodium: 3,200 milligrams.
The recommended limit for seniors: 1,500 to 2,000 milligrams.
He was consistently over by 60 percent — and he had no idea.

The culprit? Not what he expected.
Not the saltshaker at the table.
It was canned soups. Packaged bread. Deli meat for lunch.
Hidden sodium he couldn't see or taste.

Average daily sugar: 42 grams.
Mostly from fruit juice — which feels healthy but spikes blood sugar fast.
Switching to whole fruit instead of juice — same nutrition, much slower sugar release.

The insight that changed his eating the most?
Not a rule. Not a restriction.
It was just seeing the numbers. For the first time in his life, he could SEE what he was actually eating.

'I had no idea that soup had that much salt. I thought it was healthy,' he told me.

That's the power of AI diet tracking. It's not about judgment.
It's about information. And information leads to better choices."

---

### [SEGMENT 6 — 3 HABITS STARTING TONIGHT — 9:45–11:00]

**[ON SCREEN: Clean three-step graphic]**

**JAKE:**
"Here are three habits you can start tonight — no apps required yet.

Habit One: Take a photo of every meal starting today.
Even if you don't analyze it yet — build the habit of capturing what you eat.
Your photo library becomes your food diary automatically.
When you're ready to use Calorie Mama, you already have a week of data.

Habit Two: Drink water before every meal.
One full glass of water 15 minutes before eating.
Research consistently shows this reduces caloric intake by 13 percent on average — simply by reducing hunger signals.
Free. No app required. Starts tonight.

Habit Three: Replace one red-food item per day with a green food.
Just one.
Not a complete diet overhaul.
One small swap every day.
Chips with lunch → apple slices. White bread → whole grain.
In 30 days, that's 30 small improvements. Compounding daily."

---

### [OUTRO — SAYING + RECAP — 11:00–11:45]

**JAKE:**
"Today's American Saying: 'Let food be thy medicine and medicine be thy food.'
Attributed to Hippocrates — the father of modern medicine — over 2,400 years ago.

AI diet apps are how we put that ancient wisdom into daily practice.
Every meal you photograph. Every nutrient you track.
Every swap from red to green.
That is your food becoming your medicine.

Quick recap:
One: Calorie Mama — take a photo, get instant nutrition analysis. Free.
Two: Noom — green means go, yellow means mindful, red means limit. Simple.
Three: ChatGPT — type your health conditions and ask for a customized meal plan. Free.
Four: Start tonight — photo of your next meal, one glass of water before eating, one swap.

Here's my challenge to you this week:
Photograph three meals and share your biggest surprise in the comments.
What did AI reveal about your diet that you didn't expect?

I read every comment. I'm Jake. This has been AI Decoded for Seniors, Episode 28.
See you next time."

**[END SCREEN: Subscribe + EP29 preview + playlist]**

---

## 📋 PRODUCTION CHECKLIST

- [ ] Record intro scene (emotional doctor's office framing — sets stakes immediately)
- [ ] Screen record Calorie Mama live demo with real food photo scan
- [ ] Screen record Noom green/yellow/red categories tour
- [ ] Screen record ChatGPT meal planning prompt and response
- [ ] Add nutrition fact callouts as animated text overlays
- [ ] Add medical disclaimer card at start AND at ChatGPT segment
- [ ] Closed captions (auto-generate + manual review)
- [ ] Add all chapter timestamps to description
- [ ] Thumbnail: Before (messy food diary) vs After (clean phone app showing "980 cal") split
- [ ] End screen: 20-second countdown with subscribe + EP29 card

---

*Disclaimer: All nutritional information is for educational purposes only. Calorie counts and nutritional data from AI apps are estimates. Always consult your physician or registered dietitian for medically-supervised dietary guidance.*

*Sources: Calorie Mama Official Documentation; Noom App (noom.com); OpenAI ChatGPT; "AI in Nutritional Assessment," Journal of Nutrition, 2025*

---
---
---

# EP28 — YOUTUBE SHORTS / TIKTOK / REELS SCRIPTS
# Updated: 2026-04-28

---

## SHORT #1 — "The Photo Trick" (Highest viral potential)

**Hook text (0–2 sec):** "Stop counting calories. Do THIS instead. 📸"

[0:00–0:04] TEXT ON SCREEN: "Old way: write down every food. 😩"
"New way: take ONE photo. 🤩"

[0:04–0:12] JAKE: "Calorie Mama app. Free. Take a photo of your meal. AI identifies every food item and calculates the full nutritional breakdown — calories, carbs, sodium, sugar — in about 3 seconds."

[0:12–0:22] TEXT ON SCREEN + JAKE:
"Bowl of oatmeal: 150 cal ✅"
"Banana: 105 cal ✅"
"Orange juice: 112 cal ⚠️ (sugar spike)"
"Total: 367 cal | Sodium: 180mg | Sugar: 38g"

[0:22–0:38] JAKE: "Grandpa Bob photographed his meals for 30 days. The biggest surprise? Not the salt he was adding. The hidden sodium in his canned soup — 3 times over the daily limit."

[0:38–0:52] JAKE: "You can't fix what you can't see. AI shows you exactly what's in your food. No typing. No measuring. Just your phone and your plate."

[0:52–0:58] CTA: "App name: Calorie Mama. Free. Download tonight. Full guide in bio."

**Caption:** Stop counting calories by hand. This free AI app does it from one photo — in 3 seconds. #AIDiet #CalorieMama #FoodTracking #SeniorHealth #AICalorie #NutritionAI

---

## SHORT #2 — "The Noom Traffic Light" (Educational, very shareable)

**Hook:** "Green = eat freely. Yellow = be careful. Red = limit. That's it. That's the whole diet system. 🟢🟡🔴"

[0:00–0:05] JAKE: "Noom uses a traffic light system for food. It's the simplest diet framework I've ever seen — and it works."

[0:05–0:25] TEXT FLASH SEQUENCE:
"🟢 GREEN — Vegetables, fruits, whole grains, lean protein → EAT FREELY"
"🟡 YELLOW — Lean meats, low-fat dairy, beans → EAT MINDFULLY"
"🔴 RED — Fried food, processed snacks, sweets → LIMIT"

[0:25–0:40] JAKE: "You don't count calories. You don't read labels. You just ask: is this green, yellow, or red? And you eat accordingly. Even Grandpa Bob said — even I can follow a stoplight."

[0:40–0:52] JAKE: "Try this today: look at your next three meals. Classify each item as green, yellow, or red. Just noticing — no restriction — already starts changing what you reach for."

[0:52–0:58] CTA: "Full episode linked. Follow for daily senior AI tips."

**Caption:** Noom's traffic light diet system is the simplest healthy eating framework I've ever seen. Green = go. Yellow = mindful. Red = limit. That's it. #Noom #AIDiet #SeniorHealth #HealthyEating #NutritionAI

---

## SHORT #3 — "ChatGPT Meal Plan" (Aspirational, high search)

**Hook:** "I asked ChatGPT to make a meal plan for a diabetic 72-year-old. The result was incredible."

[0:00–0:06] JAKE: "Type this into ChatGPT: 'Create a 7-day low-sodium, low-sugar meal plan for a 72-year-old with Type 2 diabetes. Simple meals. I don't like fish.'"

[0:06–0:22] TEXT ON SCREEN — ChatGPT response excerpt:
"Monday Breakfast: Steel-cut oats with cinnamon and blueberries. Est. 220 cal, 8g sugar."
"Monday Lunch: Grilled chicken breast with roasted vegetables. Est. 380 cal, 2g sugar."
"[continues for 7 days...]"

[0:22–0:38] JAKE: "Complete week of meals. Breakfast, lunch, dinner, snacks. Customized for diabetes and sodium limits. Takes 30 seconds. Free."

[0:38–0:50] JAKE: "Important: ChatGPT is an AI tool, not a doctor. Always share any meal plan with your physician before making big dietary changes. But as a STARTING POINT? Remarkable."

[0:50–0:58] CTA: "Full guide + Calorie Mama + Noom tutorial in bio. Follow for more."

**Caption:** I asked ChatGPT to make a 7-day diabetic meal plan for a senior. 30 seconds. Free. Completely customized. Here's what it produced. #ChatGPT #AIDiet #DiabeticDiet #MealPlanning #SeniorNutrition
