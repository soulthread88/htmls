# EP30 — AI IMAGE GENERATION PROMPTS
# AI Shopping Comparison — Lowest Price Every Time
# Updated: 2026-04-28

---

## IMAGE SLOT 1 — Intro / Blog Header (16:9)
Context: Senior comparing prices online — Google Shopping on screen

### Midjourney v6:
```
elderly american man (70s) smiling while looking at laptop showing price comparison results across multiple stores, bright home office setting, reading glasses on, coffee cup nearby, warm morning light, realistic photography, sense of satisfaction and discovery, 16:9 --ar 16:9 --v 6 --style raw
```

### DALL-E 3:
```
Photorealistic image: A pleased elderly man (70s) with reading glasses, looking at a laptop screen showing a price comparison chart with multiple store logos and varying prices. Warm, bright home setting. Morning light through window. Coffee cup on desk. Horizontal 16:9. No real brand logos visible.
```

### Stock Alternative Search:
- "senior man laptop online shopping comparison"
- "elderly person comparing prices computer"
- "grandfather shopping online savings"

---

## IMAGE SLOT 2 — Tech Concept (16:9)
Context: Price history graph / CamelCamelCamel style chart

### Midjourney v6:
```
clean data visualization infographic showing a price history line graph for a product over 12 months, line drops dramatically showing good buying moments circled in green, "sale" label shown as fake vs real sale comparison, minimal design, blue and orange color scheme, educational consumer infographic, 16:9 --ar 16:9 --v 6
```

### DALL-E 3:
```
Clean educational infographic: A price history line graph showing a product's price over 12 months. The line fluctuates, with some low points circled in green (labeled "Real Deal") and a high point labeled "Fake Sale" with a red X. Simple, clear data visualization. Blue and orange color scheme. No brand logos. Horizontal 16:9.
```

---

## IMAGE SLOT 3 — Saying / "Look Before You Leap" (16:9)
Context: Visual metaphor for careful decision-making before purchase

### Midjourney v6:
```
vintage americana illustration, person carefully peering over edge of cliff before stepping, lush landscape below, metaphor for careful research before decision, warm gold and navy colors, editorial illustration style, no modern branding, optimistic and empowering mood, 16:9 --ar 16:9 --v 6
```

### DALL-E 3:
```
Vintage editorial illustration: A figure carefully peering over the edge of a stepping stone before jumping, lush landscape visible below. Visual metaphor for "look before you leap." Warm gold and deep navy color palette. Encouraging, empowering mood. No text. Horizontal 16:9.
```

---

## VISUAL STORY PANELS (1:1 Square)

### Panel 1 — "Grandpa Bob Is Confused by All the Prices!"
```
friendly cartoon illustration of a puzzled elderly man surrounded by floating price tags showing different numbers, overwhelmed expression, laptop and smartphone visible, multiple shopping site logos as generic icons, warm colors, humorous educational cartoon, square format --ar 1:1 --v 6
```

### Panel 2 — "AI Finds the Lowest Price!"
```
cartoon illustration of a smartphone showing a comparison chart with prices lined up, a green checkmark highlighting the lowest price, magnifying glass effect, happy discovery moment, clean data visualization cartoon style, square format --ar 1:1 --v 6
```

### Panel 3 — "Smart Shopping — Mission Accomplished!"
```
cartoon illustration of a happy elderly man giving thumbs up holding a small package delivery box, gold savings coins floating around him, smartphone showing "SAVED $18" on screen, celebratory warm colors, friendly victory scene cartoon, square format --ar 1:1 --v 6
```

---

## AI ICON GRID (4 × 1:1 small squares)

### Icon 1 — Price Chart (📈)
```
minimalist icon: upward/downward price line chart with a search magnifying glass overlay, data visualization aesthetic, teal and white on dark background, clean app icon style, 1:1 square
```

### Icon 2 — Star Review (⭐)
```
minimalist icon: five-star rating with AI brain wave passing through it, AI review summary concept, gold stars on white background, clean modern design, 1:1 square
```

### Icon 3 — Credit Card Discount (💳)
```
minimalist icon: credit card with percentage sign and downward price arrow, discount/cashback concept, green and white, clean financial icon style, 1:1 square
```

### Icon 4 — Package Delivery (📦)
```
minimalist icon: cardboard box with a green checkmark and "FREE" shipping ribbon, delivery success concept, warm brown and green, clean friendly icon style, 1:1 square
```

---

## YOUTUBE THUMBNAIL SPEC

**Concept:** Price shock + resolution
- LEFT: Two price tags side by side — "$69.99" (red X) vs "$51.87" (green circle)
- BELOW TAGS: "Same product. Same Amazon. Same week."
- CENTER: Bold white text "AI FOUND THE REAL PRICE"
- BOTTOM BANNER: "AI Decoded for Seniors | EP.30" gold on navy
- REACTION: Grandpa Bob face — shocked on left → smiling on right (optional)

**Alternative thumbnail:**
- CamelCamelCamel price history graph screenshot (dramatic dip showing the real low)
- Bold text overlay: "Is That Amazon 'Sale' FAKE? 🐪"

---

## SERIES WRAP-UP SPECIAL IMAGE (Optional — for promoting the full EP26–30 series)

### Midjourney v6:
```
clean editorial illustration showing 5 smartphone screens arranged in arc formation, each showing a different AI health/lifestyle app interface, warm gold and navy color scheme, "Episode 26-30" banner, educational technology series visual, no real brand logos, 16:9 --ar 16:9 --v 6
```

Use this image for:
- Series playlist thumbnail on YouTube
- Instagram "series complete" announcement post
- SubStack "complete series" email

---

## IMAGE SPECS

| Slot | Size | Format |
|---|---|---|
| Blog Headers (1,2,3) | 1200×630 | JPG |
| YouTube Thumbnail | 1280×720 | JPG |
| Story Panels (×3) | 1080×1080 | JPG/PNG |
| Icon Grid (×4) | 400×400 | PNG |
| Instagram Carousel | 1080×1080 | JPG |
| Instagram Story | 1080×1920 | JPG |
| Series wrap-up special | 1280×720 | JPG |

## ⚖️ COPYRIGHT NOTE
All generated images are original AI creations — no copyright issues.
Do not include real Google, Amazon, or CamelCamelCamel logos in generated images.
For website screenshots used in content: caption as "Screenshot: [Site Name], [Date]"
