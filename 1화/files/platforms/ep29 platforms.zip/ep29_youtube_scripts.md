# EP29 — YOUTUBE SCRIPTS (LONG-FORM + SHORTS)
# Papago vs DeepL vs ChatGPT — The Ultimate Translation AI Showdown
# Updated: 2026-04-28

---

## ▶ LONG-FORM VIDEO METADATA

**Title (A/B Test A):**
Grandpa Got a Letter in English — AI Translated It Instantly! (Papago vs DeepL vs ChatGPT for Seniors)

**Title (A/B Test B):**
Point Your Camera at ANY Foreign Language — It Translates in Real Time! | Complete AI Translation Guide for Seniors

**Description:**
Grandpa Bob received a letter from his grandson in America. It was entirely in English. He couldn't read a single word.

Jake held up a phone camera to the letter — and Korean text appeared floating right over the English words. Instantly.

In Episode 29 of AI Decoded for Seniors, Jake compares three powerful free AI translation tools — so you know exactly which one to use, when:

✅ Papago — best for Asian languages, real-time camera translation
✅ DeepL — best for European languages, full document translation
✅ ChatGPT — best for writing replies, understanding context & idioms
✅ Bonus: voice translation, PDF documents, writing letters to family overseas

No foreign language knowledge needed. No dictionary. Just your phone.

🕐 CHAPTERS:
0:00 — The English letter Grandpa Bob couldn't read
1:15 — Why AI translation beats dictionaries
2:30 — Papago: camera translation demo (real-time)
4:15 — Papago: voice translation (AI interpreter)
5:30 — DeepL: full document & PDF translation
7:00 — ChatGPT: write a letter in any language
8:30 — Comparison: when to use which tool
9:45 — "It's not what you say, it's how you say it" — Today's Saying
10:45 — Quiz + Recap
11:30 — Jake's challenge to viewers

📌 Free tools:
• Papago: https://papago.naver.com/ (App: search "Papago" on App Store / Google Play)
• DeepL: https://www.deepl.com/
• ChatGPT: https://chat.openai.com/

#AITranslation #PapagoApp #DeepL #ChatGPT #SeniorTech #AIForSeniors

---

## 🎬 FULL LONG-FORM SCRIPT

---

### [INTRO — 0:00–1:15]

**[ON SCREEN: A handwritten envelope with US stamps. An elderly man slowly opens it. The letter is in English — dense paragraphs, cursive handwriting. He squints. Confusion on his face.]**

**JAKE (V.O.):**
"Grandpa Bob's grandson studies abroad in America.
Every few months, he sends a handwritten letter.
This one arrived last Tuesday.
Grandpa Bob looked at it for a long time.
He couldn't read a single word.
He didn't want to admit it."

**[CUT TO: Jake, warm and upbeat, direct to camera]**

**JAKE:**
"Language barriers are something that affects millions of American families every single day.
Whether it's a letter from overseas, a menu at a Japanese restaurant, a medical report in a foreign language, or trying to speak to someone who doesn't share your language —

AI translation has completely solved this problem.
And the three tools we're covering today are all completely free.

Today, Grandpa Bob will be able to read that letter.
Write one back.
And never feel blocked by a language barrier again.

I'm Jake. This is AI Decoded for Seniors. Let's go."

---

### [SEGMENT 1 — WHY AI TRANSLATION BEATS DICTIONARIES — 1:15–2:30]

**[ON SCREEN: Side-by-side: a thick foreign dictionary vs. a smartphone screen]**

**JAKE:**
"First — a quick history lesson that sets up everything else.

Traditional dictionaries translate word by word. But language doesn't work word by word.

Take this Japanese phrase: 木で鼻を括る.
Word for word: 'tie your nose with a tree.'
Actual meaning: 'to give a cold, dismissive response.'

A dictionary gives you nonsense. AI translation understands context, idiom, tone.

That's the revolution. Modern AI translators — especially DeepL and ChatGPT — don't just match words. They understand the meaning behind sentences, the cultural context around phrases, and the appropriate tone for different situations.

For seniors — especially those with family overseas, or who travel — this changes everything.

Let me show you all three tools in action."

---

### [SEGMENT 2 — PAPAGO: CAMERA TRANSLATION — 2:30–4:15]

**[ON SCREEN: Papago app demo — camera pointed at English letter]**

**JAKE:**
"Papago is made by Naver — Korea's largest tech company — and it's the gold standard for Korean, Japanese, and Chinese translation.

Its headline feature: Camera Translation.

Here's exactly how it works:

Step One: Download Papago from the App Store or Google Play. Free.

Step Two: Open the app. Tap the camera icon at the bottom — it looks like a viewfinder.

Step Three: Point your camera at any foreign text.
The English on Grandpa Bob's letter.
The Japanese on a restaurant menu.
The French on a product label.

Step Four: Watch the magic.
Within about one second, the translated text appears overlaid directly on top of the original — right through your camera screen.
English words replaced by Korean. In real time. As you move the camera.

Step Five: Tap the shutter button to capture and translate a still image.
You can save the translated version, zoom in, or copy the text.

[PAUSE — show result]

Grandpa Bob held his phone over his grandson's letter.
His grandson had written: 'Grandpa, I think about you every day. I hope you are staying healthy and that the spring flowers are beautiful there.'

Grandpa Bob read it in Korean. On his phone. For the first time.

He didn't say anything for a moment.
Then: 'He thinks about me every day.'

That's what AI translation does.
It doesn't just translate words. It connects people."

---

### [SEGMENT 3 — PAPAGO VOICE TRANSLATION — 4:15–5:30]

**[ON SCREEN: Papago voice interpreter mode demo]**

**JAKE:**
"Papago also works as a real-time voice interpreter — perfect for travel or speaking with someone who doesn't share your language.

Here's how:
Tap the microphone icon in Papago.
Select your language on the left — Korean, for example — and the target language on the right — English.
Tap the microphone button.
Speak in Korean.
Papago translates and speaks the English aloud — immediately.

The other person taps their side and responds in English.
Papago translates that to Korean for you.

A full two-way conversation across two languages. Through one phone. Free.

Real-world uses:
At a foreign restaurant: point at the menu, camera translates every dish.
At a foreign pharmacy: speak your symptom, get the English equivalent.
Meeting someone from another country: complete conversation through the phone.

Papago currently supports 13 languages — covering most of Asia, and the major European languages as well."

---

### [SEGMENT 4 — DEEPL: DOCUMENT TRANSLATION — 5:30–7:00]

**[ON SCREEN: DeepL website — document upload demo]**

**JAKE:**
"Now for DeepL — the tool that professional translators worldwide consider the most accurate for European languages.

DeepL is exceptional at nuance. It doesn't just translate — it finds the most natural, context-appropriate phrasing.

But its standout feature for seniors: full document translation.

Here's how:
Go to deepl.com on your phone or computer. It's free.
Tap 'Translate Files' at the top.
Upload a PDF, Word document, or PowerPoint file.
Select your target language.
DeepL translates the entire document — preserving the original formatting, layout, and structure.

The translated document downloads automatically.

Use cases that matter for seniors:
An overseas medical report — translated to English, original format preserved.
A legal document from a foreign country — complete translation in minutes.
A long letter written by a foreign relative — full document, perfect layout.
An overseas purchase warranty or user manual.

One important note: DeepL's free tier allows up to 3 document translations per month.
The paid version — around $8 per month — removes this limit. For occasional use, free is more than enough."

---

### [SEGMENT 5 — CHATGPT: WRITE IN ANY LANGUAGE — 7:00–8:30]

**[ON SCREEN: ChatGPT conversation demo on laptop]**

**JAKE:**
"And now for my personal favorite use case — one that moved Grandpa Bob more than anything else in this episode.

After reading his grandson's letter — he wanted to write back. In English.

He typed this into ChatGPT:
'My grandson is studying abroad in America. He sent me a heartfelt letter. I want to write back in English and tell him how proud I am of him, that I miss him, and that the spring flowers are beautiful here. Please write a warm, natural-sounding letter for me.'

ChatGPT responded with a complete, beautifully written letter.
Natural English. Warm tone. Age-appropriate.
All Grandpa Bob had to do was copy it, sign his name, and mail it.

[READ EXCERPT — on screen text:]
'My dear [grandson's name],
Your letter arrived on a Tuesday morning, and I have read it more times than I can count. You said you think about me every day — I want you to know that not a single day passes here that I don't think of you too...'

Grandpa Bob's hands were shaking a little when he read it.
'This sounds like me,' he said. 'But better.'

That's what ChatGPT does for language.
It doesn't replace your voice. It amplifies it.

Other powerful ChatGPT translation prompts:
'Translate this email I received from [country] and explain any cultural references I might not understand.'
'I need to communicate with my Japanese doctor. Translate these symptoms into Japanese.'
'Explain this legal document from [country] in simple English — what are the key things I need to know?'

ChatGPT understands context. It explains idioms. It clarifies ambiguity.
No other translation tool does this."

---

### [SEGMENT 6 — WHICH TOOL TO USE WHEN — 8:30–9:45]

**[ON SCREEN: Simple comparison table]**

**JAKE:**
"Let me give you the quick decision guide — so you always know which tool to reach for.

Papago: Use this when you're pointing your camera at foreign text in real time. Signs, menus, labels, handwritten letters. Also best for Korean-Japanese-Chinese translation accuracy. Also use it for live voice conversation with a foreign speaker.

DeepL: Use this when you have a full document — PDF, Word file, legal paper, medical report — that needs to be translated in its entirety, preserving the original formatting. Also excellent for European languages where it outperforms every other tool.

ChatGPT: Use this when you need to WRITE something in a foreign language, when you need cultural context explained, when you want a translation that sounds natural rather than mechanical, or when you need to understand the meaning and implications of a complex document — not just its literal words.

The three tools together — completely free — cover every translation need you will ever have.
Foreign restaurant. Overseas letter. Medical document. Writing to family. Live conversation.
All covered."

---

### [OUTRO — SAYING + RECAP — 9:45–11:30]

**JAKE:**
"Today's American Saying: 'It's not what you say, it's how you say it.'

The best AI translators don't just translate words — they capture the tone, warmth, and feeling behind them.
That's why Grandpa Bob's letter to his grandson — written with ChatGPT's help — sounded like him. Just better.

Because what matters isn't word-for-word accuracy.
What matters is that the person on the other side feels what you intended them to feel.

Quick recap:
One: Papago — camera translation, voice translation, Asian languages. Free.
Two: DeepL — full document translation, European languages, preserves formatting. Free for 3 files/month.
Three: ChatGPT — write in any language, understand cultural context, explain complex documents. Free.

My challenge to you this week:
Take one photo of something in a foreign language — a product label, a restaurant sign, anything — and translate it with Papago.
Then share what you found in the comments. I want to know what surprised you.

I'm Jake. This has been AI Decoded for Seniors, Episode 29.
See you next time."

**[END SCREEN: Subscribe + EP30 preview + playlist]**

---

## 📋 PRODUCTION CHECKLIST

- [ ] Recreate the letter-opening intro scene (emotional anchor — most important shot)
- [ ] Screen record Papago camera translation live (real foreign text — Japanese menu works perfectly)
- [ ] Screen record Papago voice interpreter mode (two-language conversation demo)
- [ ] Screen record DeepL document translation (upload PDF, show translated output)
- [ ] Screen record ChatGPT writing the grandfather's letter (show the prompt + response)
- [ ] Add the "comparison table" as an animated graphic
- [ ] Closed captions (important — many seniors watch with sound low)
- [ ] Add all chapter timestamps to description
- [ ] Thumbnail: Phone camera hovering over foreign text → Korean/English translation overlay appearing
- [ ] End screen: 20-second countdown

---

*Disclaimer: AI translation tools provide estimates and may not be accurate for all contexts. For legal, medical, or official document translation, a certified human translator is recommended.*
*Sources: Naver Papago Official Documentation (2025); DeepL Official Website (2025); OpenAI ChatGPT (2025)*

===================================================================

# EP29 — YOUTUBE SHORTS / TIKTOK / REELS SCRIPTS

---

## SHORT #1 — "The Camera Magic" (Highest viral potential — visual payoff)

**Hook text (0–2 sec):** "Point your phone at ANY foreign language. Watch what happens. 📱"

[0:00–0:03] TEXT ON SCREEN (slow reveal):
"Japanese menu. Chinese label. English letter."
"One app. One second."

[0:03–0:12] JAKE (fast, direct):
"Papago app. Free. Open it → tap Camera → point at any foreign text.
AI reads it and puts the translation right on top of the original. In real time. Like magic."

[0:12–0:28] TEXT FLASH with visual:
"Japanese restaurant menu → Korean in 1 second ✅"
"French wine label → English instantly ✅"
"Handwritten letter in English → Korean on top ✅"
"No typing. No dictionary. Just point."

[0:28–0:42] JAKE:
"Grandpa Bob hadn't been able to read his grandson's letter for three days.
Jake held up the phone.
One second later: Korean text floating over every English word.
Grandpa Bob read the whole letter. Right there."

[0:42–0:55] JAKE:
"Download Papago. Free. Search it on the App Store or Google Play.
Tap Camera. Point at any foreign text.
That's your whole tutorial."

[0:55–0:58] CTA: "Follow for more AI tools that actually change lives for seniors."

**Caption:** Point your camera at any foreign language and it translates instantly. Papago app — free. Here's Grandpa Bob reading his grandson's letter for the first time. #AITranslation #PapagoApp #CameraTranslation #SeniorTech #AIForSeniors

---

## SHORT #2 — "ChatGPT Wrote His Letter" (Emotional angle — highly shareable)

**Hook:** "Grandpa Bob couldn't write to his grandson in English. Then he asked ChatGPT. 🥺"

[0:00–0:05] JAKE:
"His grandson lives in America. Grandpa Bob wanted to write back — in English.
He doesn't speak English. He asked ChatGPT for help."

[0:05–0:20] TEXT ON SCREEN (ChatGPT prompt):
"'My grandson studies in America. Write a warm letter telling him I'm proud of him, I miss him, and the spring flowers are beautiful here. In natural English.'"

[0:20–0:38] JAKE (reading excerpt):
"ChatGPT wrote: 'My dear [name], your letter arrived on a Tuesday morning, and I have read it more times than I can count. You said you think about me every day — I want you to know that not a single day passes that I don't think of you too...'"

[0:38–0:50] JAKE (quiet, genuine):
"Grandpa Bob read it and said: 'This sounds like me. But better.'
He copied it, signed his name, and mailed it.
His grandson called him the day it arrived."

[0:50–0:58] CTA: "ChatGPT is free. chat.openai.com. Full guide in bio — includes Papago and DeepL too."

**Caption:** ChatGPT wrote a letter to his American grandson — in natural English — in 30 seconds. Grandpa Bob copied it, signed his name, and mailed it. His grandson called the day it arrived. #ChatGPT #AITranslation #FamilyCommunication #SeniorTech #AIForSeniors

---

## SHORT #3 — "Papago vs DeepL vs ChatGPT — Which One?" (Decision guide)

**Hook:** "3 free AI translators. Which one should YOU use? 30-second decision guide."

[0:00–0:03] JAKE: "Three free AI translation tools. Three completely different use cases. Here's the 30-second guide."

[0:03–0:20] RAPID TEXT SEQUENCE:
"📷 PAPAGO → Use for: Camera translation. Voice translation. Asian languages."
"Real-time. On your phone. 1 second."

[0:20–0:37]
"📄 DEEPL → Use for: Full documents. PDFs. European languages."
"Upload a file → entire document translated. Preserves original format."

[0:37–0:52]
"🤖 CHATGPT → Use for: Writing in foreign language. Understanding context. Explaining idioms."
"Sounds natural. Captures tone. Explains meaning — not just words."

[0:52–0:58] JAKE: "All three = free. Together = zero language barriers. Full guide in bio."

**Caption:** Papago vs DeepL vs ChatGPT — which AI translator should you use? 30-second decision guide. All three are completely free. #AITranslation #PapagoApp #DeepL #ChatGPT #SeniorTech #LanguageAI
